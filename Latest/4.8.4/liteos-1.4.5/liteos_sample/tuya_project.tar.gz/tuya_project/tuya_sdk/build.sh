#! /bin/sh

# ./build.sh 分支名称


SRC_BRANCH=$1
SRC_DIR=ipc_common_platform
SRC_GIT_PATH=https://code.registry.wgine.com/hardware_core/ipc_common_platform
CUR_DIR=`pwd`

if [ ! -d ${SRC_DIR} ]; then
	git clone ${SRC_GIT_PATH}
fi

cd ${SRC_DIR}

# 更新文件
git checkout ${SRC_BRANCH}
git pull

# 编译
./build_ipc.sh sdk liteos_ppcs_all_wifi_dev liteos_tuya

# 拷贝头文件及库
cp output/liteos_tuya_liteos_ppcs_all_wifi_dev/tuya_ipc_sdk/libs/libtuya_ipc.a ${CUR_DIR}/../lib/
cp -rf output/liteos_tuya_liteos_ppcs_all_wifi_dev/tuya_ipc_sdk/include/*.h ${CUR_DIR}/../include/tuya/

cd -


