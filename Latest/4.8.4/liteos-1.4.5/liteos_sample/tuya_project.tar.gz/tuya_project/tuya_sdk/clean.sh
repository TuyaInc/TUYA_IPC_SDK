#! /bin/sh


SRC_DIR=ipc_common_platform

if [ -d ${SRC_DIR} ]; then
	rm -rf ${SRC_DIR}
fi
