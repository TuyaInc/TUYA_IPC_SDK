/******************************************************************************
  Some simple Hisilicon Hi35xx system functions.

  Copyright (C), 2010-2015, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2015-6 Created
******************************************************************************/
#include "sys/types.h"

#include "sys/time.h"
#include "unistd.h"
#include "fcntl.h"
#include "sys/statfs.h"

#include "los_event.h"
#include "los_printf.h"

#include "lwip/tcpip.h"
#include "lwip/netif.h"
#include "eth_drv.h"
#include "arch/perf.h"

#include "fcntl.h"
#include "shell.h"
#include "stdio.h"
#include "hisoc/uart.h"

#include "fs/fs.h"
#include "shell.h"
#include "vfs_config.h"
#include "disk.h"
#include "los_cppsupport.h"

//#include "higmac.h"
#include "proc_fs.h"
#include "console.h"
#include "hirandom.h"
#include "nand.h"
#include "spi.h"
#include "dmac_ext.h"
#include "mtd_partition.h"

#include "limits.h"
#include "linux/fb.h"

#include "securec.h"
#include "los_cppsupport.h"

extern char __init_array_start__, __init_array_end__;

extern int mem_dev_register(void);
extern UINT32 osShellInit();
extern void CatLogShell();
extern void hisi_eth_init(void);
//extern void tools_cmd_register(void);
extern void proc_fs_init(void);
extern int uart_dev_init(void);
extern int system_console_init(const char *);
extern int nand_init(void);
extern int add_mtd_partition( char *, UINT32 , UINT32 , UINT32 );
extern int spinor_init(void);
extern int spi_dev_init(void);
extern int i2c_dev_init(void);
extern int gpio_dev_init(void);
extern int dmac_init(void);
extern int ran_dev_register(void);

extern int mount(const char   *device_name,
              const char   *path,
              const char   *filesystemtype,
              unsigned long rwflag,
              const void   *data);


struct netif* pnetif;
extern void SDK_init(void);
extern int app_main(int argc, char* argv[]);
extern void fuvc_frame_descriptors_set(void);
#define CHIP_HI3516C_V200   0x3516C200
#define CHIP_HI3518E_V200   0x3518E200
#define CHIP_HI3518E_V201   0x3518E201

//define, max args ---20
#define  ARGS_SIZE_T         20
#define  ARG_BUF_LEN_T       256
static char *ptask_args[ARGS_SIZE_T];
static char *args_buf_t = NULL;

static int taskid = -1;

//#define WIFI_USAGE

#ifdef WIFI_USAGE
extern void wifi_init(void);
#endif

int secure_func_register(void)
{
    int ret;
    STlwIPSecFuncSsp stlwIPSspCbk= {0};
    stlwIPSspCbk.pfMemset_s = memset_s;
    stlwIPSspCbk.pfMemcpy_s = memcpy_s;
    stlwIPSspCbk.pfStrNCpy_s = strncpy_s;
    stlwIPSspCbk.pfStrNCat_s = strncat_s;
    stlwIPSspCbk.pfStrCat_s = strcat_s;
    stlwIPSspCbk.pfMemMove_s = memmove_s;
    stlwIPSspCbk.pfSnprintf_s = snprintf_s;
    stlwIPSspCbk.pfRand = rand;
    ret = lwIPRegSecSspCbk(&stlwIPSspCbk);
    if (ret != 0)
    {
        PRINT_ERR("\n***lwIPRegSecSspCbk Failed***\n");
        return -1;
    }

    PRINTK("\nCalling lwIPRegSecSspCbk\n");
    return ret;
}


void com_app(unsigned int p0, unsigned int p1, unsigned int p2, unsigned int p3)
{
    int i = 0;
    unsigned int argc = p0;
    char **argv = (char **)p1;

    //Set_Interupt(0);

    dprintf("\ninput command:\n");
    for(i=0; i<argc; i++) {
        dprintf("%s ", argv[i]);
    }
    dprintf("\n");
    app_main(argc,argv);
    dprintf("\nmain out\n");

    dprintf("[END]:app_test finish!\n");
    free(args_buf_t);
    args_buf_t = NULL;
    taskid = -1;
}

void app_process(int argc, char **argv )
{
    int i = 0, ret = 0;
    int len = 0;
    char *pch = NULL;
    TSK_INIT_PARAM_S stappTask;

    if(argc < 1) {
        dprintf("illegal parameter!\n");
    }

    if (taskid != -1) {
        dprintf("There's a app_main task existed.\n");
    }
    args_buf_t = zalloc(ARG_BUF_LEN_T);
    memset(&stappTask, 0, sizeof(TSK_INIT_PARAM_S));
    pch = args_buf_t;
    for(i=0; i<ARGS_SIZE_T; i++) {
        ptask_args[i] = NULL;
    }
    argc++;
    ptask_args[0] = "app_process";

    for(i = 1; i < argc; i++)
    {
        len =  strlen(argv[i-1]);
        memcpy(pch , argv[i-1], len);
        ptask_args[i] = pch;
        //keep a '\0' at the end of a string.
        pch = pch + len + 1;
        if (pch >= args_buf_t +ARG_BUF_LEN_T) {
            dprintf("args out of range!\n");
            break;
        }
    }
    memset(&stappTask, 0, sizeof(TSK_INIT_PARAM_S));
    stappTask.pfnTaskEntry = (TSK_ENTRY_FUNC)com_app;
    stappTask.uwStackSize  = 0x80000;
    stappTask.pcName = "app_process";
    stappTask.usTaskPrio = 10;
    stappTask.uwResved   = LOS_TASK_STATUS_DETACHED;
    stappTask.auwArgs[0] = argc;
    stappTask.auwArgs[1] = (UINT32)ptask_args;
    ret = LOS_TaskCreate((UINT32 *)&taskid, &stappTask);

    dprintf("camera_Task %d,ret is %d\n", taskid,ret);

    //chdir("/sd0");
    chdir("/nfs");

}

void sample_command(void)
{
    osCmdReg(CMD_TYPE_EX, "process", 0, (CMD_CBK_FUNC)app_process);
}

void net_init(void)
{
	(void)secure_func_register();
	tcpip_init(NULL, NULL);
#ifdef LOSCFG_DRIVERS_HIGMAC
    extern struct los_eth_driver higmac_drv_sc;
    pnetif = &(higmac_drv_sc.ac_if);
    higmac_init();
#endif

#ifdef LOSCFG_DRIVERS_HIETH_SF
    extern struct los_eth_driver hisi_eth_drv_sc;
    pnetif = &(hisi_eth_drv_sc.ac_if);
    hisi_eth_init();
#endif

    dprintf("cmd_startnetwork : DHCP_BOUND finished\n");
    netif_set_up(pnetif);
#ifndef WIFI_USAGE	
    netifapi_dhcp_stop(pnetif);
    netifapi_dhcp_start(pnetif);
#endif
}

extern char shell_working_directory[PATH_MAX];

extern unsigned int g_uwFatSectorsPerBlock;
extern unsigned int g_uwFatBlockNums;

extern UINT32 g_sys_mem_addr_end;
extern unsigned int g_uart_fputc_en;
void board_config(void)
{
    g_sys_mem_addr_end = SYS_MEM_BASE + SYS_MEM_SIZE_DEFAULT;
    g_uwSysClock = OS_SYS_CLOCK;
    g_uart_fputc_en = 1;
    extern unsigned long g_usb_mem_addr_start;
    g_usb_mem_addr_start = g_sys_mem_addr_end;

    g_uwFatSectorsPerBlock = CONFIG_FS_FAT_SECTOR_PER_BLOCK;
    g_uwFatBlockNums       = CONFIG_FS_FAT_BLOCK_NUMS;
}



void app_init(void)
{
    extern int SD_MMC_Host_init(void);
    extern UINT32 usb_init(void);
    extern int spinor_init(void);

    dprintf("cxx init ...\n");

    LOS_CppSystemInit((unsigned long)&__init_array_start__, (unsigned long)&__init_array_end__, NO_SCATTER);

#ifndef WIFI_USAGE
    dprintf("os vfs init ...#####\n");
    proc_fs_init();
    mem_dev_register();

    dprintf("uart init ...\n");
    uart_dev_init();
    dprintf("shell init ...\n");
    system_console_init(TTY_DEVICE);
    osShellInit(TTY_DEVICE);		//����̨����ָ���
    //shell_cmd_register();  

    dprintf("spi nor flash init ...\n");
    if (!spinor_init())
    {
        //add_mtd_partition("spinor", 0x800000, 2 * 0x100000, 0);
        //add_mtd_partition("spinor", 10 * 0x100000, 2 * 0x100000, 1);
	    //mount("/dev/spinorblk0", "/jffs0", "jffs", 0, NULL);
    }

    dprintf("spi bus init ...\n");
    spi_dev_init();

    dprintf("i2c bus init ...\n");
    i2c_dev_init();

    dprintf("gpio init ...\n");
    gpio_dev_init();

    dprintf("sd/mmc host init ...\n");
    SD_MMC_Host_init();
    sleep(1);
    mount("/dev/mmcblk0p0", "/sd0", "vfat", 0, 0);

    dprintf("dmac init\n");
    dmac_init();

    dprintf("random init ...\n");
    ran_dev_register();

 //   dprintf("tcpip init ...\n");
 //   (void)secure_func_register();
 //   tcpip_init(NULL, NULL);

    #ifdef LOSCFG_DRIVERS_USB
		#ifdef LOSCFG_DRIVERS_USB_UVC_GADGET
			dprintf("usb fuvc frame set...\n");
			fuvc_frame_descriptors_set();
		#endif

		extern unsigned int g_usb_mode_is_dfu;
		g_usb_mode_is_dfu = 0; // 0:uvc mode;1:dfu mode

	    dprintf("usb init ...\n");
	    //usb_init must behind SD_MMC_Host_init
	    usb_init();
	#endif

    dprintf("net init ...\n");
    net_init();

    dprintf("Now shell working dir is :%s\n", shell_working_directory);
    dprintf("g_sys_mem_addr_end=0x%08x,\n", g_sys_mem_addr_end);

#else

    dprintf("os vfs init ...#####\n");
    proc_fs_init();
    mem_dev_register();
    dprintf("dmac init\n");
    dmac_init();
    dprintf("spi bus init ...\n");
    spi_dev_init();
    dprintf("i2c bus init ...\n");
    i2c_dev_init();
    dprintf("run wifi init\n");
    //wifi_init();	todo ʵ��wifi�ĳ�ʼ��
#endif

    CatLogShell();   //cat_logmpp

    dprintf("done init!\n");
    dprintf("Date:%s.\n", __DATE__);
    dprintf("Time:%s.\n", __TIME__);

    SDK_init();
    sample_command();
    //app_process(0, NULL);
	dprintf("#####run app over\n");
    //tools_cmd_register();
    return;
}

/* EOF kthread1.c */
