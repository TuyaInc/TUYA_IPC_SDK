/*********************************************************************************
  *Copyright(C),2017, 涂鸦科技 www.tuya.comm
  *FileName:    tuya_ipc_cloud_storage.h
**********************************************************************************/

#ifndef __TUYA_IPC_CLOUD_STORAGE_H__
#define __TUYA_IPC_CLOUD_STORAGE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_ipc_media.h"

/**
 * \brief 云存储状态
 * \struct ClOUD_STORAGE_STATUS_E
 */
typedef enum
{
    ClOUD_STORAGE_STATUS_INIT = 0,      //第一次开机状态
    ClOUD_STORAGE_STATUS_READY,         //订单状态正常
    ClOUD_STORAGE_STATUS_UPLOADING,     //数据上传中
    ClOUD_STORAGE_STATUS_HTTPC_ERROR,   //上传失败
    ClOUD_STORAGE_STATUS_ODER_INVALID,  //订单异常
    ClOUD_STORAGE_STATUS_INVALID
}ClOUD_STORAGE_STATUS_E;

/**
 * \brief 云存储store mode
 * \struct ClOUD_STORAGE_TYPE_E
 */
typedef enum
{
    ClOUD_STORAGE_TYPE_CONTINUE,  /**< 连续上传云存储数据，结束以订单结束时间为准 */
    ClOUD_STORAGE_TYPE_EVENT,  /**< 事件区间上传云存储数据，结束以硬件告知sdk结束为准或订单告知结束为准 */ 
    ClOUD_STORAGE_TYPE_INVALID
}ClOUD_STORAGE_TYPE_E;

typedef enum
{
    ClOUD_STORAGE_VIDEO_FILE = 0,
    ClOUD_STORAGE_AUDIO_FILE,
    ClOUD_STORAGE_TS_FILE,
    ClOUD_STORAGE_PICTURE_FILE,
    ClOUD_STORAGE_INDEX_FILE,
    ClOUD_STORAGE_FILE_TYPE_MAX
}ClOUD_STORAGE_FILE_TYPE_E;

/**
 * \brief the nalu type of H264E
 * \struct ClOUD_STORAGE_H264_SLICE_E
 */
typedef enum 
{
     VIDEO_H264_NALU_P = 1,
     VIDEO_H264_NALU_I = 5,
     VIDEO_H264_NALU_SEI = 6,
     VIDEO_H264_NALU_SPS = 7,
     VIDEO_H264_NALU_PPS = 8,
     VIDEO_H264_NALU_IP = 9,
     VIDEO_H264_NALU_MAX
} ClOUD_STORAGE_H264_SLICE_E;

typedef enum
{
    VIDEO_H264_P_FRAME = 0,
    VIDEO_H264_I_FRAME = 1
}CLOUD_STORAGE_H264_FRAME_E;

typedef int (*Tuya_CBC_AES128_Init)(unsigned int phy_input_len, unsigned int phy_output_len, unsigned char **pInputAddr,
                                    unsigned char **pOutputAddr);
typedef int (*Tuya_CBC_AES128_Encrypt)( unsigned char *pdata_in,  unsigned int data_len,
                                             unsigned char *pdata_out,  unsigned int *pdata_out_len,
                                             unsigned char *pkey, unsigned char *piv);
typedef int (*Tuya_CBC_AES128_Decrypt)(unsigned char *pdata_in,  unsigned int data_len,
                                            unsigned char *pdata_out,  unsigned int *pdata_out_len,
                                            unsigned char *pkey, unsigned char *piv);
typedef int (*Tuya_CBC_AES128_Destroy)();


/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_init
 * \brief 启动云存储
 * \param[in] media_setting 多媒体配置信息
 * \param[in] snapshot_buffer 快照截图。事件存储时，使用该截图作为APP上视频缩略图。置为NULL则不生成。
 * \param[in] snapshot_size 快照截图大小。
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_cloud_storage_start(IPC_MEDIA_INFO_S *media_setting, CHAR *snapshot_buffer, UINT snapshot_size);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_stop  
 * \brief 停止云存储
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_cloud_storage_stop(VOID);

/**
 * \fn OPERATE_RET tuya_ipc_upload_media_frame
 * \brief 往云服务器上传数据接口
 * \param[in] frame 上传的数据帧信息
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_upload_media_frame(IN MEDIA_FRAME_S *frame);

/**
 * \fn OPERATE_RET tuya_ipc_register_CBC_AES128_Function
 * \brief 数据AES加密接口
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_register_CBC_AES128_Function(Tuya_CBC_AES128_Init init_fun, Tuya_CBC_AES128_Encrypt encrypt_fun,
                                                            Tuya_CBC_AES128_Decrypt decrypt_fun, Tuya_CBC_AES128_Destroy destroy_fun);

#ifdef __cplusplus
}
#endif

#endif
