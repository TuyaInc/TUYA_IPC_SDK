/*********************************************************************************
  *Copyright(C),2015-2020, 
  *TUYA 
  *www.tuya.comm
  *FileName:    tuya_ipc_face_detect_demo
**********************************************************************************/

#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include "tuya_ipc_ai_face_detect.h"

#define TYDEBUG printf
#define TYERROR printf

//According to different chip platforms, users need to implement the interface of capture.
void gen_new_face_message(AI_NEW_FACE_IMAGE_CTL_S* p_new_face)
{
    // use demo file to simulate
    if(p_new_face == NULL)
    {
        return;
    }
    char snapfile[128];
    p_new_face->ai_face_image.face_image_size = 0;
    extern char s_raw_path[];
    printf("get new face snapshot\n");
    snprintf(snapfile,64,"%s/resource/media/demo_face_snapshot.jpg",s_raw_path);
    FILE*fp_face = fopen(snapfile,"r+");
    if(NULL == fp_face)
    {
        printf("fail to open snap.jpg\n");
        return;
    }
    fseek(fp_face,0,SEEK_END);
    p_new_face->ai_face_image.face_image_size = ftell(fp_face);
    if(p_new_face->ai_face_image.face_image_size < 100*1024)
    {
        fseek(fp_face,0,SEEK_SET);
        fread(p_new_face->ai_face_image.face_image_add,p_new_face->ai_face_image.face_image_size,1,fp_face);
    }
    fclose(fp_face);

    snprintf(snapfile,64,"%s/resource/media/demo_scence_snapshot.jpg",s_raw_path);
    FILE*fp_scence = fopen(snapfile,"r+");
    if(NULL == fp_scence)
    {
        printf("fail to open snap.jpg\n");
        return;
    }
    fseek(fp_scence,0,SEEK_END);
    p_new_face->ai_face_image.face_image_size = ftell(fp_scence);
    if(p_new_face->ai_face_image.face_image_size < 100*1024)
    {
        fseek(fp_scence,0,SEEK_SET);
        fread(p_new_face->ai_face_image.face_image_add,p_new_face->ai_face_image.face_image_size,1,fp_scence);
    }
    fclose(fp_scence);

    p_new_face->scores = 80; //you should set the score
    return;
}

//According to different chip platforms, users need to implement the interface of capture.
void gen_signed_face_message(AI_SIGNED_FACE_IMAGE_CTL_S* p_signed_face)
{
    //we use file to simulate
    if(p_signed_face == NULL)
    {
        return;
    }
    char snapfile[128];
    p_signed_face->ai_face_image.face_image_size = 0;
    p_signed_face->ai_face_image.scene_image_size = 0;
    extern char s_raw_path[];
    printf("get signed face snapshot\n");
    snprintf(snapfile,64,"%s/resource/media/demo_signed_face.jpg",s_raw_path);
    FILE*fp_face = fopen(snapfile,"r+");
    if(NULL == fp_face)
    {
        printf("fail to open snap.jpg\n");
        return;
    }
    fseek(fp_face,0,SEEK_END);
    p_signed_face->ai_face_image.face_image_size = ftell(fp_face);
    if(p_signed_face->ai_face_image.face_image_size < 100*1024)
    {
        fseek(fp_face,0,SEEK_SET);
        fread(p_signed_face->ai_face_image.face_image_add,p_signed_face->ai_face_image.face_image_size,1,fp_face);
    }
    fclose(fp_face);

    snprintf(snapfile,64,"%s/resource/media/demo_signed_scence.jpg",s_raw_path);
    FILE*fp_scence = fopen(snapfile,"r+");
    if(NULL == fp_scence)
    {
        printf("fail to open snap.jpg\n");
        return;
    }
    fseek(fp_scence,0,SEEK_END);
    p_signed_face->ai_face_image.scene_image_size = ftell(fp_scence);
    if(p_signed_face->ai_face_image.scene_image_size < 100*1024)
    {
        fseek(fp_scence,0,SEEK_SET);
        fread(p_signed_face->ai_face_image.scene_image_add,p_signed_face->ai_face_image.scene_image_size,1,fp_scence);
    }
    fclose(fp_scence);

    p_signed_face->faceid = 10000;  //you should set your faceid
    return;
}

/*update local face data from the service*/
int tycam_ai_face_update()
{
    TYDEBUG("begin__");
    int i=0;
    int res = 0;
    AI_FACE_ALL_GET_S *cloud_face_para = NULL;
    AI_FACE_IMAGE_DOWN_S *face_download_para = NULL;
    
    face_download_para =(AI_FACE_IMAGE_DOWN_S *)malloc(sizeof(AI_FACE_IMAGE_DOWN_S));

    res = tuya_ipc_ai_face_all_get(&cloud_face_para);   //get url

    if(res != OPRT_OK)
    {
        goto exit;
    }

    TYDEBUG("cloud_face_para->face_all_num = %d \n",cloud_face_para->face_all_num);
    for (i = 0; i < cloud_face_para->face_all_num; i++)
    {
        //ty_cfg_is_exist(face_download_para->);
        memcpy(face_download_para->fw_url,cloud_face_para->face_all[i].face_url,FACE_URL_LEN);
        memcpy(face_download_para->pic_key,cloud_face_para->face_all[i].face_key,FACE_KEY_LEN);
        face_download_para->encrypt = cloud_face_para->face_all[i].encrypt;
        
        TYDEBUG("encrypt %d \n",face_download_para->encrypt);
        /*this is a demo to storage the download picture*/
        char base[256];
        sprintf(base,"/tmp/face/%d",cloud_face_para->face_all[i].face_id);

        if((access(base,F_OK)) == 0)   
        {
            TYDEBUG("(access(base,F_OK)) == 0  face_id = %d \n",cloud_face_para->face_all[i].face_id);
            continue;
        }
        TYDEBUG("(access(base,F_OK)) != 0  face_id = %d \n",cloud_face_para->face_all[i].face_id);

        res = tuya_ipc_ai_face_pic_download(&face_download_para);
        if(res!=0)
        {
            goto exit;
        }
        /*save or send it to AI detect base face_download_para*/
        /*
        FILE* pfile = fopen(base, "wb");
        if (!pfile) {
            PR_ERR("open audio file fail!\n");
        }
        if(pfile != NULL) {
            fwrite(face_download_para->pic_src, 1, face_download_para->pic_len, pfile);
            fflush(pfile);
            fclose(pfile);
            pfile = NULL;
        }
        */
    }
    
    TYDEBUG("download pic done !\n");

exit:
    if(cloud_face_para->face_all != NULL)
    {
        free(cloud_face_para->face_all);
    }

    if(cloud_face_para != NULL)
    {
        free(cloud_face_para);
        cloud_face_para=NULL;
    }

    if(face_download_para != NULL)
    {
        free(face_download_para);
    }
    return res;
}

/* face_id_list: [1,2,3,4,5] */
void tycam_ai_face_cfg_func(IN CONST CHAR_T* action, IN CONST CHAR_T* face_id_list)
{
    TYDEBUG("tycam_ai_face_cfg_func\n");
    if((action == NULL) || (face_id_list == NULL))
    {
        return ;
    }
    else
    {
        if(strcmp(action,"add") == 0)
        {
            tycam_ai_face_update();
        }
        else if(strcmp(action,"delete") == 0)
        {
            /* delete local face data within face_id_list*/
        }
        else if(strcmp(action,"update") == 0)
        {
            tycam_ai_face_update();
        }
    }
    return ;
}

int get_frame_yuv_data(char **fram_yuv)
{
    /*get frame yuv data*/
    return 0;
}

BOOL_T send_and_detect_face(char *yuv)
{   BOOL_T ret =0;
    /*if it has face set 1,nor set 0*/
    return ret;
}


BOOL_T compare_face_is_strange(char *yuv)
{   BOOL_T ret =0;
    /*if it is strange set 1,nor set 0*/
    return ret;
}

int save_data_base_id(unsigned int face_id)
{
    /*save the date base face id*/
    return 0;
}

/*init callback to TUYA SDK*/
void tycam_face_sdk_func_init(void)
{
    tuya_ipc_ai_face_detect_storage_init(tycam_ai_face_cfg_func); 
    tycam_ai_face_update();
    return;
}

VOID *thread_face_dectect_proc(VOID *arg)
{
    BOOL_T is_strange = 0;
    char *yuv = NULL;
    AI_NEW_FACE_IMAGE_CTL_S new_up_load_buffer={0};
    AI_SIGNED_FACE_IMAGE_CTL_S signed_up_load_buffer={0};
    unsigned int face_id =0;
    tycam_face_sdk_func_init();

    while (1)
    {
        usleep(100*1000);
        get_frame_yuv_data(&yuv);
        BOOL_T has_face = send_and_detect_face(yuv);
        if(has_face)
        {
            is_strange = compare_face_is_strange(yuv);
            if(is_strange)
            {
                gen_new_face_message(&new_up_load_buffer);
                tuya_ipc_ai_face_new_report(&new_up_load_buffer,&face_id);
                save_data_base_id(face_id);
            }
            else
            {
                gen_signed_face_message(&signed_up_load_buffer);
                tuya_ipc_ai_face_signed_report(&signed_up_load_buffer);
            }

        }

    }
    return NULL;
}

