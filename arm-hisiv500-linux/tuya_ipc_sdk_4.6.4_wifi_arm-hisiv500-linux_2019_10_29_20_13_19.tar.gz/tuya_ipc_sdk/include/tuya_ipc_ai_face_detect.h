#ifndef __TUYA_IPC_AI_FACE_DETECT_H__
#define __TUYA_IPC_AI_FACE_DETECT_H__

#ifdef __cplusplus
extern "C" {
#endif
#include "tuya_ipc_cloud_storage.h"

#define FACE_KEY_LEN 16
#define FACE_URL_LEN 300
#define FACE_PIC_MAX_SIZE (150*1024)

typedef struct
{
    CHAR_T* face_image_add;
    INT_T face_image_size;
    CHAR_T* scene_image_add;
    INT_T scene_image_size;
}AI_FACE_IMAGE_CTL_ES;

/*new face struct*/
typedef struct
{
    AI_FACE_IMAGE_CTL_ES ai_face_image;
    INT_T scores;       //face scores
}AI_NEW_FACE_IMAGE_CTL_S;

/*signed face struct*/
typedef struct
{
    AI_FACE_IMAGE_CTL_ES ai_face_image;
    INT_T faceid;
}AI_SIGNED_FACE_IMAGE_CTL_S;

/*face info struct */
typedef struct
{
    CHAR_T face_url[FACE_URL_LEN];   //the url download
    UINT_T face_id;                 //face_id
    CHAR_T face_key[FACE_KEY_LEN];  //face key
    BOOL_T encrypt;                 //if it is TRUE you should provide a key ,False you don't
}AI_FACE_ALL_GET;

typedef struct
{
    AI_FACE_ALL_GET *face_all;
    UINT_T face_all_num;        //face num
}AI_FACE_ALL_GET_S;

/*face download*/
typedef struct
{
    CHAR_T fw_url[FACE_URL_LEN] ;
    CHAR_T pic_key[FACE_KEY_LEN] ;
    CHAR_T pic_src[FACE_PIC_MAX_SIZE];
    INT_T pic_len;
    BOOL_T encrypt;
}AI_FACE_IMAGE_DOWN_S;


typedef VOID (*IPC_AI_FACE_DETECT_CB)(IN CONST CHAR_T* action, IN CONST CHAR_T* face_id_list);

/**
 * \fn OPERATE_RET tuya_ipc_ai_face_detect_storage_init 
 * \brief 
 * \     Init ai face detect. 
 * \     callback to set ai_cfg of callback[del add update]
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_ai_face_detect_storage_init(IPC_AI_FACE_DETECT_CB cb);

/**
 * \fn OPERATE_RET tuya_ipc_ai_face_all_get 
 * \brief 
 * \
 * \     tuya_ipc_ai_face_all_get:get face pic from server
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_ai_face_all_get(AI_FACE_ALL_GET_S** pp_ai_face_all_get);

/**
 * \fn OPERATE_RET tuya_ipc_ai_face_signed_report  
 * \brief device upload signed face pic to service
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_ai_face_signed_report(AI_SIGNED_FACE_IMAGE_CTL_S * ai_face_image);


/**
 * \fn OPERATE_RET tuya_ipc_ai_face_new_report  
 * \brief 
 * device upload new face pic to service
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_ai_face_new_report(AI_NEW_FACE_IMAGE_CTL_S * ai_new_face_image, OUT UINT_T *face_id);

/**
 * \fn OPERATE_RET tuya_ipc_ai_face_pic_download  
 * \brief 
 * device download face pic from service
 * \return OPERATE_RET
 */

OPERATE_RET tuya_ipc_ai_face_pic_download(AI_FACE_IMAGE_DOWN_S **ai_face_down);


#ifdef __cplusplus
}
#endif

#endif

