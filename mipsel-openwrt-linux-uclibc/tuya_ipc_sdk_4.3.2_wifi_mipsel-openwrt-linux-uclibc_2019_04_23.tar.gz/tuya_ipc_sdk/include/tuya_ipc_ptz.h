#ifndef _MOTOR_PRESET_OPERATION_H_
#define _MOTOR_PRESET_OPERATION_H_
#include "tuya_cloud_types.h"

#define  MAX_PRESET_NUM 6

typedef struct {
    INT_T   pan;
    INT_T   tilt;
    INT_T   zoom;
}S_PRESET_PTZ;

typedef struct {
    CHAR_T        id[32];        //id in server
    CHAR_T       name[32];  //preset point name
    INT_T        mpId;      //收藏点索引ID
    S_PRESET_PTZ ptz;       //位置信息
} S_PRESET_POSITION;

typedef struct {
    INT_T  num;
    S_PRESET_POSITION position[MAX_PRESET_NUM];
} S_PRESET_CFG;

/**
 * \fn OPERATE_RET tuya_ipc_preset_add(CHAR_T *addr, UINT_T size, S_PRESET_POSITION* preset_pos)
 * \brief 添加收藏点接口
 * \param[in] addr and size 扩展用，暂时不用，addr可以设置为NULL，size可以设置为0
 * \param[in] preset_pos 添加的收藏点信息
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_preset_add(CHAR_T *addr, UINT_T size, S_PRESET_POSITION* preset_pos);


/**
 * \fn OPERATE_RET tuya_ipc_preset_del(IN CHAR_T* preset_id)
 * \brief 删除收藏点接口
 * \param[in] preset_id，设备在服务端注册的预设点id号
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_preset_del(IN CHAR_T* preset_id);


/**
 * \fn OPERATE_RET tuya_ipc_preset_get(S_PRESET_CFG *preset_cfg)
 * \brief 获取收藏点接口
 * \param[in] preset_cfg
 * \return OPERATE_RET，通过调用该接口可以同步设备和服务器之间的收藏点信息
 */
OPERATE_RET tuya_ipc_preset_get(S_PRESET_CFG *preset_cfg);


/**
 * \fn OPERATE_RET tuya_ipc_preset_add_pic(CHAR_T *addr, UINT_T size, S_PRESET_POSITION* preset_pos)
 * \brief 添加收藏点图片接口
 * \param[in] preset_pos 扩展用，暂时不用
 * \param[in] addr图片存储地址，size为图片的大小
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_preset_add_pic(CHAR_T *addr, UINT_T size, S_PRESET_POSITION* preset_pos);


#endif

