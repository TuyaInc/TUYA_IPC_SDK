/*********************************************************************************
  *Copyright(C),2017, 涂鸦科技 www.tuya.comm
  *FileName:    tuya_ipc_mqt_proccess.h
**********************************************************************************/

#ifndef __TUYA_IPC_MQT_PROCCESS_H__
#define __TUYA_IPC_MQT_PROCCESS_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"

#define PRO_CLOUD_STORAGE_REQ 300 /* cloud storage request */
#define PRO_AI_SCREEN_REQ 301 /* echo show request or chromecast request */

typedef VOID (*IPC_ECHO_SHOW_CB)(IN CONST CHAR_T* url);

/**
 * \typedef  typedef VOID (*GW_CLOUD_STORAGE_CB)(IN CONST CHAR* action, IN CONST CHAR* store_mode);
  * \brief 云存储功能开启服务回调回调函数定义
 * \param[in] action: store/abort
 * \param[in] store_mode: event/continue
 */
typedef VOID (*IPC_CLOUD_STORAGE_CB)(IN CONST CHAR_T* action, IN CONST CHAR_T* store_mode);

/**
 * \typedef typedef VOID (*GW_CHROMECAST_CB)(IN CONST CHAR* url)
 * \brief CHROMECAST 服务回调函数定义
 * \param[in] url
 */
typedef VOID (*IPC_CHROMECAST_CB)(IN CHAR_T* url);

VOID tuya_ipc_mqt_EchoShowCb(IN CONST IPC_ECHO_SHOW_CB echo_show_cb);

VOID tuya_ipc_mqt_ChromeCastCb(IN CONST IPC_CHROMECAST_CB chromecast_cb);

VOID tuya_ipc_mqt_CloudStorageCb(IN CONST IPC_CLOUD_STORAGE_CB cloud_storage_cb);

VOID iot_register_extra_mqt_cb(VOID);

typedef struct {	
	IPC_ECHO_SHOW_CB echo_show_cb;
	IPC_CLOUD_STORAGE_CB cloud_storage_cb;
	IPC_CHROMECAST_CB chromecast_cb;
}IPC_MQT_CTRL_S;


#ifdef __cplusplus
}
#endif

#endif

