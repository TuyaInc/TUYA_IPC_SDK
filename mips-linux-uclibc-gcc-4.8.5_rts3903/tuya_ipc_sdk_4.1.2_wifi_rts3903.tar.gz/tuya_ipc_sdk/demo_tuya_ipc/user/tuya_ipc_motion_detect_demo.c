/*********************************************************************************
  *Copyright(C),2015-2020, 涂鸦科技 www.tuya.comm
  *FileName:    tuya_ipc_motion_detect_demo
**********************************************************************************/

#include <stdio.h>
#include "tuya_ipc_cloud_storage.h"
#include "tuya_ipc_stream_storage.h"
#include "tuya_ipc_notification.h"

//需要开发者实际实现的接口，根据不同的芯片平台，获得当前帧是否存在移动的判断结果
int get_motion_status()
{
    //if motion detected ,return 1
    return 0;
    //else return 0
    //return 0;
}

//需要开发者实际实现的接口，根据不同的芯片平台，获得一个JPEG格式快照图片
void get_motion_snapshot(char *snap_addr, int *snap_size)
{
    //这里用文件来模拟
    char snapfile[128];
    *snap_size = 0;
    extern char s_raw_path[];
    snprintf(snapfile,64,"%s/rawfiles/tuya_logo.jpg",s_raw_path);
    FILE*fp = fopen(snapfile,"r+");
    if(NULL == fp)
    {
        printf("fail to open snap.jpg\n");
        return;
    }
    fseek(fp,0,SEEK_END);
    *snap_size = ftell(fp);
    if(*snap_size < 100*1024)
    {
        fseek(fp,0,SEEK_SET);
        fread(snap_addr,*snap_size,1,fp);
    }
    fclose(fp);
    return;
}

VOID *thread_md_proc(VOID *arg)
{
    int motion_flag = 0;
    int motion_alarm_is_triggerd = FALSE;
    char snap_addr[100*1024] = {0}; //快照最大100KB
    int snap_size = 0;
    int md_peace_cnt = 0;
    int md_enable = 0;

    while (1)
    {
        usleep(100*1000);
        md_enable = IPC_APP_get_alarm_function_onoff();
        if(!md_enable)
        {
            continue;
        }
        motion_flag = get_motion_status();
        if(motion_flag)
        {
            md_peace_cnt = 0;
            if(!motion_alarm_is_triggerd)
            {
                motion_alarm_is_triggerd = TRUE;
                //开启本地SD卡事件存储
                tuya_ipc_ss_start_event();
                get_motion_snapshot(snap_addr,&snap_size);
                if(snap_size > 0)
                {
                    //推送告警消息到消息中心
                    IPC_APP_Send_Motion_Alarm_From_Buffer(snap_addr,snap_size,NOTIFICATION_CONTENT_JPEG);
                    //上报云存储事件（无论订单类型是否事件存储）
                    tuya_ipc_cloud_storage_event_start(snap_addr,snap_size,EVENT_TYPE_MOTION_DETECT);
                }

                //说明1：考虑推送和存储的实时性，可以在不同的任务中异步执行以上接口
                //说明2：开启存储后，SDK内部会维护时间，超过最大事件时长自动停止
                //       如果需要维护超长时间不丢失存储，需要通过tuya_ipc_ss_get_status和tuya_ipc_cloud_storage_get_event_status
                //       监控SDK内部是否已经有停止事件录像，并择机再重新start新的事件
            }
        }
        else
        {
            //画面静止
            md_peace_cnt++;
            //静止超过4秒，停止事件
            if(md_peace_cnt > 40 && motion_alarm_is_triggerd)
            {
                tuya_ipc_ss_stop_event();
                tuya_ipc_cloud_storage_event_stop();
                md_peace_cnt = 0;
                motion_alarm_is_triggerd = FALSE;
            }
        }
    }

    return NULL;
}
