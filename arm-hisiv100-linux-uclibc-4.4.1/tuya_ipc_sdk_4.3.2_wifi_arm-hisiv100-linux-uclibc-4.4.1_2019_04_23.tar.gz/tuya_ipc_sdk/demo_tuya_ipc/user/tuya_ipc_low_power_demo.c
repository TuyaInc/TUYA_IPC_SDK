/*********************************************************************************
  *Copyright(C),2015-2020, 涂鸦科技 www.tuya.comm
  *FileName:    tuya_ipc_p2p_demo
**********************************************************************************/
#include <stdlib.h>
#include "tuya_ipc_common_demo.h"
#include "tuya_ipc_media.h"
#include "tuya_ipc_dp_utils.h"
#include "tuya_ipc_stream_storage.h"

/*
---------------------------------------------------------------------------------
低功耗接入参考代码
en:TRUE进入休眠      FALSE休眠唤醒
---------------------------------------------------------------------------------
*/
STATIC CHAR_T s_wakeup_data[32] = {0};
STATIC UINT_T s_wakeup_len = 32;
STATIC INT_T s_wakeup_fd = -1;
STATIC pthread_t s_wake_send_pthread = -1;
STATIC BOOL_T s_wake_task_stat = FALSE;


void __wakeup_task(void * argv)
{
    PR_DEBUG("into task");
    CHAR_T buffer[32];
    while(TRUE == s_wake_task_stat){
        //持续接收唤醒数据
        recv(s_wakeup_fd, buffer, s_wakeup_len, 0);
        //用户确保wakeup数据接收完整
        if (0 == strncmp(buffer, s_wakeup_data, s_wakeup_len)){
            //用户接收到唤醒数据,做相应的唤醒后处理
            /*********************/
            /*********************/
            /*********************/
            /*********************/
            return ;
        }
    }

    return ;
}

OPERATE_RET TUYA_APP_LOW_POWER_ENABLE()
{
    PR_DEBUG("low power en");
    BOOL_T  doorStat = FALSE;
    OPERATE_RET ret = 0;

    //上报休眠状态给tuya
    ret = tuya_ipc_dp_report(NULL, TUYA_DP_DOOR_STATUS,PROP_BOOL,&doorStat,1);
    if (OPRT_OK != ret){
        //次dp点比较重要，如果失败，用户最好重复调用report接口，直到上报成功
        //若持续失败，用户需检查设备网络连接状态
        PR_ERR("dp report failed");
        return ret;
    }
    ret = tuya_ipc_book_wakeup_topic();
    if (OPRT_OK != ret){
        PR_ERR("tuya_ipc_book_wakeup_topic failed");
        return ret;            
    }
    ret = tuya_ipc_get_wakeup_data(s_wakeup_data, &s_wakeup_len);
    if (OPRT_OK != ret){
        PR_ERR("tuya_ipc_get_wakeup_data failed");
        return ret;   
    }

    int i = 0;

    for(i = 0; i < s_wakeup_len; i++) {
        printf("%x ", s_wakeup_data[i]);
    }

    printf("\n");

    //获取fd，用于与服务端进行唤醒交互
    s_wakeup_fd =  tuya_ipc_get_mqtt_socket_fd();
    if (-1 == s_wakeup_fd){
        PR_ERR("tuya_ipc_get_mqtt_socket_fd failed");
        return ret; 
    }

    //创建sock接收线程，接收唤醒包
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 1024 * 1024);
    s_wake_task_stat = TRUE;
    ret = pthread_create(&s_wake_send_pthread, &attr, __wakeup_task, NULL);
    if (OPRT_OK != ret){
        PR_ERR("task create failed");
        s_wake_task_stat = FALSE;
        return ret;
    }
    pthread_attr_destroy(&attr);

    return ret;
}

OPERATE_RET TUYA_APP_LOW_POWER_DISABLE()
{
    BOOL_T  doorStat = TRUE;
    OPERATE_RET ret = 0;

    //关闭唤醒数据接收线程
    if (-1 != s_wake_send_pthread){
        s_wake_task_stat = FALSE;
        pthread_join(s_wake_send_pthread, NULL);
    } 
    ret = tuya_ipc_dp_report(NULL, TUYA_DP_DOOR_STATUS,PROP_BOOL,&doorStat,1);
    return ret;
}

