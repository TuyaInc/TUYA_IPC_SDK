#ifndef _TUYA_IPC_MEDIA_H_
#define _TUYA_IPC_MEDIA_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"

#define MAX_MEDIA_FRAME_SIZE    (200*1024)
#define MAX_VIDEO_CHANNEL       2

typedef enum
{
    E_CHANNEL_VIDEO_MAIN = 0,    
    E_CHANNEL_VIDEO_SUB,
    E_CHANNEL_AUDIO,
    E_CHANNEL_MAX
}CHANNEL_E;

typedef enum
{
    E_VIDEO_PB_FRAME = 0,
    E_VIDEO_I_FRAME,
    E_VIDEO_TS_FRAME,
    E_AUDIO_FRAME,
    E_MEDIA_FRAME_TYPE_MAX
}MEDIA_FRAME_TYPE_E;

//该枚举值涉及与服务端、APP端共用，后续不允许改变已有枚举的值
typedef enum
{
    CODEC_VIDEO_MPEG4 = 0,
    CODEC_VIDEO_H263,
    CODEC_VIDEO_H264,
    CODEC_VIDEO_MJPEG,
    CODEC_VIDEO_H265,
    CODEC_VIDEO_MAX = 99,
    
    CODEC_AUDIO_ADPCM,
    CODEC_AUDIO_PCM,
    CODEC_AUDIO_AAC_RAW,
    CODEC_AUDIO_AAC_ADTS,
    CODEC_AUDIO_AAC_LATM,
    CODEC_AUDIO_G711U,
    CODEC_AUDIO_G711A,
    CODEC_AUDIO_G726,
    CODEC_AUDIO_SPEEX,
    CODEC_AUDIO_MP3,
    CODEC_AUDIO_MAX = 199,
    CODEC_INVALID
}TUYA_CODEC_ID;

typedef enum
{
    AUDIO_SAMPLE_8K     = 8000,
    AUDIO_SAMPLE_11K    = 11000,
    AUDIO_SAMPLE_12K    = 12000,
    AUDIO_SAMPLE_16K    = 16000,
    AUDIO_SAMPLE_22K    = 22000,
    AUDIO_SAMPLE_24K    = 24000,
    AUDIO_SAMPLE_32K    = 32000,
    AUDIO_SAMPLE_44K    = 44000,
    AUDIO_SAMPLE_48K    = 48000,
    AUDIO_SAMPLE_MAX    = 0xFFFFFFFF
}AUDIO_SAMPLE_E;

typedef enum
{
    VIDEO_BITRATE_64K   = 64,
    VIDEO_BITRATE_128K  = 128,
    VIDEO_BITRATE_256K  = 256,
    VIDEO_BITRATE_512K  = 512,
    VIDEO_BITRATE_1M    = 1024,
    VIDEO_BITRATE_2M    = 2048,
    VIDEO_BITRATE_4M    = 4096,
    VIDEO_BITRATE_8M    = 8192,
    VIDEO_BITRATE_MAX   = 0xFFFF
}VIDEO_BITRATE_E;           //Kbps

typedef enum
{
    AUDIO_DATABITS_8 = 8,
    AUDIO_DATABITS_16 = 16,
    AUDIO_DATABITS_MAX = 0xFF
}AUDIO_DATABITS_E;

typedef enum
{
    AUDIO_CHANNEL_MONO,
    AUDIO_CHANNEL_STERO,
}AUDIO_CHANNEL_E;

typedef struct
{
    BOOL channel_enable[E_CHANNEL_MAX];

    UINT video_fps[MAX_VIDEO_CHANNEL];
    UINT video_gop[MAX_VIDEO_CHANNEL];
    VIDEO_BITRATE_E video_bitrate[MAX_VIDEO_CHANNEL];
    UINT video_width[MAX_VIDEO_CHANNEL];
    UINT video_height[MAX_VIDEO_CHANNEL];
    UINT video_freq[MAX_VIDEO_CHANNEL];
    TUYA_CODEC_ID video_codec[MAX_VIDEO_CHANNEL];

    TUYA_CODEC_ID audio_codec;
    UINT audio_fps;
    AUDIO_SAMPLE_E audio_sample;
    AUDIO_DATABITS_E audio_databits;
    AUDIO_CHANNEL_E audio_channel;
}IPC_MEDIA_INFO_S;

typedef struct
{
    UINT    type;
    UINT    size;
    UINT64  timestamp;
    UINT64  pts;
}STORAGE_FRAME_HEAD_S;

typedef struct
{
    MEDIA_FRAME_TYPE_E type;
    BYTE    *p_buf;
    UINT    size;
    UINT64  pts;
    UINT64  timestamp;
}MEDIA_FRAME_S;



#ifdef __cplusplus
}
#endif

#endif /*_TUYA_IPC_MEDIA_H_*/
