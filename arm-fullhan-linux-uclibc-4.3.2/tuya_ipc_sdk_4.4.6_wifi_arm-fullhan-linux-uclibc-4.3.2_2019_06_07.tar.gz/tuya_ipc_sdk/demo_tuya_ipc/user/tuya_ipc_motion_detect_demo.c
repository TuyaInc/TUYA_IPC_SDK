/*********************************************************************************
  *Copyright(C),2015-2020, 
  *TUYA 
  *www.tuya.comm
  *FileName:    tuya_ipc_motion_detect_demo
**********************************************************************************/

#include <stdio.h>
#include "tuya_ipc_cloud_storage.h"
#include "tuya_ipc_stream_storage.h"
#include "tuya_ipc_api.h"


//AI detect should enable SUPPORT_AI_DETECT
#define SUPPORT_AI_DETECT 1
#if SUPPORT_AI_DETECT
#include "tuya_ipc_ai_detect_storage.h"
#endif

//According to different chip platforms, users need to implement whether there is motion alarm in the current frame.
int fake_md_status = 0;
int get_motion_status()
{
    //if motion detected ,return 1
    return fake_md_status;
    //else return 0
    //return 0;
}

//According to different chip platforms, users need to implement the interface of capture.
void get_motion_snapshot(char *snap_addr, int *snap_size)
{
    //we use file to simulate
    char snapfile[128];
    *snap_size = 0;
    extern char s_raw_path[];
    printf("get one motion snapshot\n");
    snprintf(snapfile,64,"%s/resource/media/demo_snapshot.jpg",s_raw_path);
    FILE*fp = fopen(snapfile,"r+");
    if(NULL == fp)
    {
        printf("fail to open snap.jpg\n");
        return;
    }
    fseek(fp,0,SEEK_END);
    *snap_size = ftell(fp);
    if(*snap_size < 100*1024)
    {
        fseek(fp,0,SEEK_SET);
        fread(snap_addr,*snap_size,1,fp);
    }
    fclose(fp);
    return;
}

#if SUPPORT_AI_DETECT
//According to different chip platforms, users need to implement the interface of capture.
VOID tuya_ipc_get_snapshot_cb(char* pjbuf, int* size)
{
    get_motion_snapshot(pjbuf,size);
}
#endif

VOID *thread_md_proc(VOID *arg)
{
    int motion_flag = 0;
    int motion_alarm_is_triggerd = FALSE;
    char snap_addr[100*1024] = {0}; //Snapshot maximum size is 100KB
    int snap_size = 0;
    int md_peace_cnt = 0;
    int md_enable = 0;
	int ret = 0;

    while (1)
    {
        usleep(100*1000);
        motion_flag = get_motion_status();
        if(motion_flag)
        {
            md_peace_cnt = 0;
            if(!motion_alarm_is_triggerd)
            {
                motion_alarm_is_triggerd = TRUE;
                //start Local SD Card Event Storage
                tuya_ipc_ss_start_event();
                get_motion_snapshot(snap_addr,&snap_size);
                if(snap_size > 0)
                {
                    //Report Cloud Storage Events 
                    //whether order type is event or continuous, a list of events is presented on APP for quick jumps.
                    tuya_ipc_cloud_storage_event_start(snap_addr,snap_size,EVENT_TYPE_MOTION_DETECT);
                    md_enable = IPC_APP_get_alarm_function_onoff();
                    if(md_enable)
                    {
						#if SUPPORT_AI_DETECT
						//use motion detect, ONLY ai_detect start failed
						if(0 != tuya_ipc_ai_detect_storage_start())
						{
							tuya_ipc_notify_motion_detect(snap_addr,snap_size,NOTIFICATION_CONTENT_JPEG);
						}						
						#else
						//When user opens the detection alarm on the APP, it pushes pictures and messages to the message center (the API is a blocking interface).
                        tuya_ipc_notify_motion_detect(snap_addr,snap_size,NOTIFICATION_CONTENT_JPEG);
						#endif
                    }                    
                }

                /*NOTE:
                ONE：Considering the real-time performance of push and storage, the above interfaces can be executed asynchronously in different tasks.
                TWO：When event cloud storage is turned on, it will automatically stop beyond the maximum event time in SDK.
                THREE:If you need to maintain storage for too long without losing it, you can use the interface (tuya_ipc_ss_get_status and tuya_ipc_cloud_storage_get_event_status).
                      to monitor whether there are stop event videos in SDK and choose time to restart new events
                */
            }
            else
            {
                //Storage interruption caused by maximum duration of internal events, restart new events
                if(SS_WRITE_MODE_EVENT == tuya_ipc_ss_get_write_mode() && E_STORAGE_STOP == tuya_ipc_ss_get_status())
                {
                    tuya_ipc_ss_start_event();
                }
                if(ClOUD_STORAGE_TYPE_EVENT == tuya_ipc_cloud_storage_get_store_mode()
                   && tuya_ipc_cloud_storage_get_event_status(EVENT_TYPE_MOTION_DETECT) == EVENT_NONE)
                {
                    get_motion_snapshot(snap_addr,&snap_size);
                    tuya_ipc_cloud_storage_event_start(snap_addr,snap_size,EVENT_TYPE_MOTION_DETECT);
                }
            }
        }
        else
        {
            //static
            md_peace_cnt++;
            //Stand still for more than 4 seconds, stop the event
            if(md_peace_cnt > 40 && motion_alarm_is_triggerd)
            {
				#if SUPPORT_AI_DETECT
				tuya_ipc_ai_detect_storage_stop();
				#endif
                tuya_ipc_ss_stop_event();
                tuya_ipc_cloud_storage_event_stop();
                md_peace_cnt = 0;
                motion_alarm_is_triggerd = FALSE;
            }
        }
    }

    return NULL;
}
#if SUPPORT_AI_DETECT
extern IPC_MEDIA_INFO_S s_media_info;
OPERATE_RET TUYA_APP_Enable_AI_Detect()
{
    tuya_ipc_ai_detect_storage_init(&s_media_info);

    return OPRT_OK;
}
#endif