/*********************************************************************************
  *Copyright(C),2017, 涂鸦科技 www.tuya.comm
  *FileName:    tuya_ipc_cloud_storage.h
**********************************************************************************/

#ifndef __TUYA_IPC_CLOUD_STORAGE_H__
#define __TUYA_IPC_CLOUD_STORAGE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_ipc_media.h"

#define MAX_SNAPSHOT_BUFFER_SIZE            (100*1024) //上报事件时的快照大小上限
#define INVALID_EVENT_ID                    0xFFFF
#define MAX_CLOUD_EVENT_DURATION            300        //事件最大长度,秒

typedef UINT_T EVENT_ID;

typedef enum
{
    EVENT_NONE,
    EVENT_ONGOING,
    EVENT_READY,
    EVENT_INVALID
}EVENT_STATUS_E;

/* 事件类型 */
typedef enum
{
    EVENT_TYPE_MOTION_DETECT,   /* 移动侦测触发的存储 */
    EVENT_TYPE_DOOR_BELL,       /* 门铃唤醒触发的存储 */
    EVENT_TYPE_DEV_LINK,        /* iot联动触发的存储 */
    EVENT_TYPE_PASSBY,          /* 正常经过，暂不支持 */
    EVENT_TYPE_LINGER,          /* 异常逗留，暂不支持 */
    EVENT_TYPE_LEAVE_MESSAGE,   /* 有留言，暂不支持 */
    EVENT_TYPE_RECORD_ONLY,     /* 无事件上报，仅录像，暂不支持 */
    EVENT_TYPE_INVALID
}ClOUD_STORAGE_EVENT_TYPE_E;

/* 云存储订单类型 */
typedef enum
{
    ClOUD_STORAGE_TYPE_CONTINUE,  /* 连续上传云存储数据，结束以订单结束时间为准 */
    ClOUD_STORAGE_TYPE_EVENT,     /* 事件区间上传云存储数据，开始、结束由自定义数据触发 */ 
    ClOUD_STORAGE_TYPE_INVALID    /* 无订单或其他异常状态 */
}ClOUD_STORAGE_TYPE_E;


/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_init  
 * \brief 云存储功能初始化
 * \param[in] media_setting 多媒体流配置信息。当为变码率或配置可能在运行中更改的情况，各个参数请传入上限值。
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_cloud_storage_init(IN IPC_MEDIA_INFO_S *media_setting, IN AES_HW_CBC_FUNC *aes_func);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_uninit  
 * \brief 云存储功能反初始化
 * \param[]
 * \return 
 */
VOID tuya_ipc_cloud_storage_uninit(VOID);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_get_store_mode  
 * \brief 获取当前云存储订单类型。
 * \return ClOUD_STORAGE_TYPE_E
 */
ClOUD_STORAGE_TYPE_E tuya_ipc_cloud_storage_get_store_mode(VOID);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_event_start  
 * \brief 上报一个事件的开始
 * \param[in] snapshot_buffer snapshot_size 当前事件发生时的快照内容与大小。最大支持100K的图片。
 * \param[in] type 事件类型
 * \return OPERATE_RET
 * \注意：该接口后续仅为兼容老版本使用，仅支持移动侦测和门铃两种事件类型，同类型事件不能重复触发
 */
OPERATE_RET tuya_ipc_cloud_storage_event_start(IN CHAR_T *snapshot_buffer, IN UINT_T snapshot_size, IN ClOUD_STORAGE_EVENT_TYPE_E type);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_event_start  
 * \brief 上报当前事件的结束。暂不支持多个事件起始-结束交叉上报。
 * \return OPERATE_RET
 * \注意：该接口后续仅为兼容老版本使用，仅用于同时停止移动侦测和门铃两种事件类型
 */
OPERATE_RET tuya_ipc_cloud_storage_event_stop(VOID);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_get_event_status  
 * \brief 根据类型获取当前事件状态。
 * \return OPERATE_RET
 */
EVENT_STATUS_E tuya_ipc_cloud_storage_get_event_status(ClOUD_STORAGE_EVENT_TYPE_E type);

/**
 * \fn VOID tuya_ipc_cloud_storage_pause  
 * \brief 暂停云存储
 * \return VOID
 */
VOID tuya_ipc_cloud_storage_pause(VOID);

/**
 * \fn VOID tuya_ipc_cloud_storage_resume  
 * \brief 恢复云存储。需要和pause接口配对使用
 * \return VOID
 */
VOID tuya_ipc_cloud_storage_resume(VOID);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_event_add  
 * \brief 新增一个事件
 * \param[in] snapshot_buffer snapshot_size 当前事件发生时的快照内容与大小。最大支持100K的图片。
 * \param[in] type 事件类型
 * \param[in] max_duration 事件最大持续时间，不能超过 MAX_CLOUD_EVENT_DURATION 大小
 * \return EVENT_ID 事件唯一ID
 */
EVENT_ID tuya_ipc_cloud_storage_event_add(CHAR_T *snapshot_buffer, UINT_T snapshot_size, ClOUD_STORAGE_EVENT_TYPE_E type, UINT_T max_duration);

/**
 * \fn OPERATE_RET tuya_ipc_cloud_storage_event_delete  
 * \brief 结束指定的事件
 * \param[in] EVENT_ID 事件唯一ID
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_cloud_storage_event_delete(EVENT_ID event_id);


#ifdef __cplusplus
}
#endif

#endif
