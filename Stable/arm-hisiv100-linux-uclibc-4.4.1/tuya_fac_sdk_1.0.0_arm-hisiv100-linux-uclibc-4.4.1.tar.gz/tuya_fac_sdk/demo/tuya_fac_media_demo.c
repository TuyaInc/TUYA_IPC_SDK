
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/statfs.h>  
#include "tuya_fac_media.h"
#include "tuya_fac_test.h"

int tuya_fac_media_start_rtsp()
{
    /* 启动RTSP Server，供上位机取流 */
    return 0;
}

int tuya_fac_media_stop_rtsp()
{
    return 0;
}

void *tuya_fac_media_loop(void *arg)
{
/*
    if(aud_save_fp){
        fwrite(audio_data, 1, node->size, aud_save_fp);
        fwrite(pcm_data, 1, node->size, aud_save_pcm_fp);
        data_size += node->size;
    }
*/
}

