#ifndef __TYCAM_FAC_TEST_H__
#define __TYCAM_FAC_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif

#include <time.h>

#define TYDEBUG(fmt, ...)  printf("Dbg:[%s:%d] "fmt"\r\n", __FUNCTION__,__LINE__,##__VA_ARGS__)


typedef struct {
	int mode ;
	int run_time;
	int quality;
	int flip;
	int log;
	struct timeval start_tv;
}tuya_FacCfg_t;

int tuya_fac_test_start(void** pphdl);

int tuya_fac_set_cfg(tuya_FacCfg_t info);

int tuya_fac_test_stop(void** pphdl);

int tuya_fac_test_loop(void* phdl , char *path);

int tuya_fac_test_loop_exit(void* phdl);


#ifdef __cplusplus
}
#endif

#endif
