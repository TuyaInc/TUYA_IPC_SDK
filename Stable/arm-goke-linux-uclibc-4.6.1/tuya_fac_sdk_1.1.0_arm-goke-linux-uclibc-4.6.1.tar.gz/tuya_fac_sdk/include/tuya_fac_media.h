#ifndef __TYCAM_FAC_MEDIA_H__
#define __TYCAM_FAC_MEDIA_H__

#ifdef __cplusplus
extern "C" {
#endif


int tuya_fac_media_init();

int tuya_fac_media_start_rtsp();

int tuya_fac_media_stop_rtsp();

void *tuya_fac_media_record(void *arg);

void *tuya_fac_media_loop(void *arg);


#ifdef __cplusplus
}
#endif

#endif
