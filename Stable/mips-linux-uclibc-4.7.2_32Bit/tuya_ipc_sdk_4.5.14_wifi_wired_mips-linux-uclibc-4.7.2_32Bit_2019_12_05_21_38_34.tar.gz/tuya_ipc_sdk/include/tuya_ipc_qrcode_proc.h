/*********************************************************************************
* Copyright(C),2019, TUYA www.tuya.com

* FileName:		tuya_ipc_qrcode_proc.h
* Note			tuya_ipc_qrcode_proc enhance
* Version		V1.0.0
* Data			2019.04
**********************************************************************************/

#ifndef _TUYA_IPC_QRCODE_PROC_H_
#define _TUYA_IPC_QRCODE_PROC_H_

#include "tuya_cloud_types.h" 
#include "tuya_cloud_error_code.h"

#define IMP_128_SHIFT8          (32768)

#ifdef __cplusplus
extern "C" {
#endif


	/*********************************************************************************
	* YUV420 image scale interface
    * in_data  		input YUV420 ,from platform decode
	* int_w			input width	,from platform decode
	* in_h			input height ,from platform dcvode
	* out_data		output YUV420 ,send in zbar
	* out_w			output width ,send in zbar
	* out_h			output height ,send in zabr
	**********************************************************************************/
	OPERATE_RET Tuya_Ipc_QRCode_Enhance(UCHAR_T *in_data, INT_T in_w, INT_T in_h, UCHAR_T **out_data, int* out_w, int* out_h);




#ifdef __cplusplus
}
#endif

#endif // !_TUYA_IPC_QRCODE_PROC_H_
