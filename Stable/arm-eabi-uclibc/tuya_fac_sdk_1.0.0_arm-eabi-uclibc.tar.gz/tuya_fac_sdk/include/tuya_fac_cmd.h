#ifndef _TUYA_FACTORY_CMD_H_
#define _TUYA_FACTORY_CMD_H_
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>

#include "tuya_fac_protocol.h"

void tuya_test_path(char *path , int verbose);

int tuya_get_version(char *buffer, int size);

int tuya_test_read_write_partition();

int tuya_test_sd_write();

int tuya_test_button();

int tuya_test_led();

int tuya_test_video();

int tuya_test_audio();

int tuya_test_ircut(char *str);

int tuya_test_speaker();

int tuya_test_mic(char *str,char *ipaddr);

int tuya_test_irled();

int tuya_test_black_video();

int tuya_read_pid(char *pid , int size);

int tuya_write_pid(char *pid , int size);

int tuya_read_uuid(char *uuid , int size);

int tuya_write_uuid(char *uuid , int size);

int tuya_read_authkey(char *authkey , int size);

int tuya_write_authkey(char *authkey , int size);

int tuya_write_cfg(char *data);

int tuya_read_cfg(char *data);

int tuya_write_SN(char *str);

int tuya_read_SN(char *data);

int tuya_write_BSN(char *str);

int tuya_read_BSN(char *data);

int tuya_read_MAC(char *data);

int tuya_write_MAC(char *str);

int tuya_write_CC(char* str);

int tuya_read_CC(char *data);

int tuya_test_wifi_strength(char *data);

int tuya_test_iperf(char *addr , char *str , double *max, double *avr, double *min);

int tuya_get_iperf_result(char *str ,double *avr_v, double *max_v , double *min_v);

int tuya_test_motor();

int tuya_test_pir();

int tuya_dn_switch_start();

int tuya_fac_aging_loop(void* phdl, char *path, int run_time);

int tuya_fac_stream_start();

int tuya_fac_stream_stop();


#endif /*_TUYA_FACTORY_CMD_H_*/
