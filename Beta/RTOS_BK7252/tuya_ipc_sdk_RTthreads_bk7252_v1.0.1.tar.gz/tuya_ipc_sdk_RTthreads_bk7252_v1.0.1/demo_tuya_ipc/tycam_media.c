#include "tuya_ipc_media_demo.h"
#include "tuya_ipc_video_proc.h"
#include "tuya_ipc_stream_storage.h"
#include "tuya_ipc_cloud_storage.h"


VOID tuya_ipc_get_snapshot_cb(char* pjbuf, unsigned int* size)
{
    //tycam_rts_get_pic(pjbuf, size);
}



