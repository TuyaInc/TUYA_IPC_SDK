#ifndef __TYCAM_MEDIA_H__
#define __TYCAM_MEDIA_H__

#include <stdint.h>
#include "tuya_hal_semaphore.h"
#include "tuya_hal_thread.h"
#include "tuya_hal_mutex.h"

#ifdef __cplusplus
extern "C" {
#endif
typedef struct tycam_dev_stream_frame_ {
    uint8_t     channel;        ///< 通道号
    uint8_t     stream_id;      ///< 码流号
    int32_t     length;         ///< 数据长度
    uint64_t    utcms;          ///< utc时间
    uint64_t    pts;            ///< pts时间
    uint32_t    seq;            ///< 序列号
    uint32_t    type;           ///< 数据流类型，表征是音频还是视频
    uint32_t    newformat;      ///< 表征是否是新格式，例如码流刚启动或高标清切换了
    uint32_t    head;           ///<
    uint32_t    tail;           ///<
    int32_t     reserved;       ///<
    void*       ptr;            ///< 数据指针

    union {
        struct {
            int8_t  encode;     ///< 编码类型，例如h264、h265等
            char  frame;        ///< 帧类型, 'I', 'P', 'B'
        } video;

        struct {
            int8_t  encode;     ///< 编码类型，例如g711、g726等
        } audio;

        // uint8_t reserved[32];
    };
} tycam_dev_stream_frame_s;

enum TYCAM_DEV_AV_MEDIA_TYPE {
    TYCAM_DEV_AV_MEDIA_TYPE_AUDIO,  ///< 音频
    TYCAM_DEV_AV_MEDIA_TYPE_VIDEO,  ///< 视频
};

typedef struct tycam_dev_stream_callback_ {
    int (*set_av_frame)(tycam_dev_stream_frame_s* pframe);
    int (*set_yuv_frame)(void *data);
    //int (*set_thumbnail)(const char *data, const uint32_t size, const NOTIFICATION_CONTENT_TYPE_E type);
} tycam_dev_stream_callback_s;

typedef struct
{
    SEM_HANDLE md_sem;
    MUTEX_HANDLE md_mutex;
}tycam_dev_stream_sync_handle;

typedef struct
{
    char * md_buf;
    //char * md_len;
}tycam_dev_stream_buf_t;

typedef struct
{
    tycam_dev_stream_callback_s         stream_cbs;
    tycam_dev_stream_sync_handle        sync_hdl;
    tycam_dev_stream_buf_t              buf_info;
}tycam_dev_stream_param_t;



#ifdef __cplusplus
}
#endif

#endif

