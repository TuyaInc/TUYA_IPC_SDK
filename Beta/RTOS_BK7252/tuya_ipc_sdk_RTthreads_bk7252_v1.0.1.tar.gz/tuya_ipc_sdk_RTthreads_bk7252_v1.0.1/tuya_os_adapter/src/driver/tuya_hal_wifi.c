/***********************************************************
*  File: wifi_hwl.c
*  Author: nzy
*  Date: 20170914
***********************************************************/
#include "general.h"

#include "tuya_hal_wifi.h"
//#include "wf_basic_intf.h"
//#include "nsapi.h"
#include "lwip/netif.h"
#include "lwip/inet.h"
#include "errors_compat.h"


#include <string.h>
//#include "uni_log.h"
//#include "lwip_stack.h"
//#include "FreeRTOS.h"
//#include "rt_task.h"
//#include "semphr.h"
//#include "main.h"
//#include <lwip_netconf.h>
//#include "tcpip.h"
//#include <wlan_test_inc.h>
//#include <dhcp/dhcps.h>

//#include "wifi_conf.h"
//#include "wifi_util.h"

//#include "tycam_qrcode.h"
//#include "tycam_dev_mgt.h"

/*
#define LOGD(...) printf("[WIFI DEBUG]" __VA_ARGS__)
#define LOGN(...) printf("[WIFI NOTICE]" __VA_ARGS__)
#define LOGI(...) printf("[WIFI INFO]" __VA_ARGS__)
#define LOGE(...) printf("[WIFI ERROR]" __VA_ARGS__)
*/


#define IP_LEN 16
#define MAX_AP_SEARCH 30

u8 sniffer_channel;

unsigned char tuya_mac_addr[6] = {0};

char tuya_ip_addr[4]    = {192, 168, 66, 1};
char tuya_msk_addr[4]   = {255, 255, 255, 0};
char tuya_gw_addr[4]    = {192, 168, 66, 1};
char tuya_dhcp_start[4] = {192, 168, 66, 100};
char tuya_dhcp_end[4] = {192, 168, 66, 255};

unsigned char tuya_wifi_state = WSS_IDLE;
extern struct netif lwip_sta_netif;
extern struct netif lwip_ap_netif;

//rda59xx_sta_info r_sta_info;
/***********************************************************
*************************micro define***********************
***********************************************************/

/***********************************************************
*************************variable define********************
***********************************************************/

u8 g_scan_flag = 0;
u8 g_scan_num = 0; 
AP_IF_S *g_ap_ary = NULL;


/***********************************************************
*  Function: wf_all_ap_scan
*  Input: none
*  Output: ap_ary->scan ap info array
*          num->scan ap nums
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_all_ap_scan(AP_IF_S **ap_ary, uint32_t *num)
{}


/***********************************************************
*  Function: wf_assign_ap_scan
*  Input: ssid->assign ap ssid
*  Output: ap->ap info
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_assign_ap_scan(const char *ssid, AP_IF_S **ap)
{
		#if 0
	int cnt = 0;
	int num = 0;
	int i,ret;

    rda59xx_scan_result *bss_list;
	rda59xx_scan_result *_bss_list;
	rda59xx_scan_info r_scan_info;
	OUT AP_IF_S *_ap_ary;

    if(NULL == ssid || \
       NULL == ap) {
        return OPRT_INVALID_PARM;
    }

	memset(&r_scan_info, 0, sizeof(rda59xx_scan_info));
	strcpy((char*)r_scan_info.SSID, ssid);
	r_scan_info.SSID_len = strlen(ssid);
	r_scan_info.channel = 0;
    cnt = mbed_lwip_scan_inf(&r_scan_info);
	if(cnt <= 0) {
        LOGE("dont find ap(%s) %d",ssid,cnt);
        return OPRT_COM_ERROR;
	}

    _bss_list = (rda59xx_scan_result *)malloc(cnt * sizeof(rda59xx_scan_result));
	bss_list = _bss_list;
	if (_bss_list == NULL) {
		LOGI("malloc buf fail");
		return OPRT_MALLOC_FAILED;
	}
    memset(_bss_list, 0, cnt * sizeof(rda59xx_scan_result));
	num = mbed_lwip_get_scan_result(_bss_list, cnt);
	LOGN("num %d cnt %d",num,cnt);

  	for(i = 0;i <num;i++) {
        ret = strcmp((const char *)(_bss_list->SSID), (const char *)ssid);
		if(ret ==0)
			break;
        _bss_list++;
    }

	if(i == num) {
        LOGE("dont find ap(%s)",ssid);
        free(bss_list);
        return OPRT_COM_ERROR;
	}
    _ap_ary = *ap = malloc(sizeof(AP_IF_S));
    memcpy(_ap_ary->ssid,_bss_list->SSID,33);
    _ap_ary->s_len = _bss_list->SSID_len;
    _ap_ary->channel = _bss_list->channel;
    _ap_ary->rssi = _bss_list->RSSI;
    memcpy(_ap_ary->bssid,_bss_list->BSSID,6);

	if(bss_list){
    	free(bss_list);
	}

    rda59xx_del_scan_all_result();
	#endif
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_release_ap
*  Input: ap
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_release_ap(AP_IF_S *ap)
{
   return 0;
}

/***********************************************************
*  Function: wf_set_cur_channel
*  Input: chan
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
u8 g_chan = 0;
int tuya_hal_wifi_set_cur_channel(const uint8_t chan)
{}

/***********************************************************
*  Function: wf_get_cur_channel
*  Input: none
*  Output: chan
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_cur_channel(uint8_t *chan)
{
   return 0;
}


/***********************************************************
*  Function: wf_sniffer_set
*  Input: en->TRUE/FALSE
*         cb->sniffer callback
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
//static VOID (*frame_cb)(IN CONST BYTE_T *buf,IN CONST USHORT_T len) = NULL;
#define SUPPORT_LDPC_PATTERN_MIMO 1
static int my_smartconfig_handler(void *data,unsigned short data_len)
{}

/***********************************************************
*  Function: wf_get_ip
*  Input: wf->WF_IF_E
*  Output: ip
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_ip(const WF_IF_E wf, NW_IP_S *ip)
{
   return 0;
}


/***********************************************************
*  Function: wf_get_mac
*  Input: wf->WF_IF_E
*  Output: mac
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_mac(const WF_IF_E wf, NW_MAC_S *mac)
{
   return 0;
}


/***********************************************************
*  Function: wf_set_mac
*  Input: wf->WF_IF_E
*         mac
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_set_mac(const WF_IF_E wf, const NW_MAC_S *maca)
{
   return 0;
}


/***********************************************************
*  Function: wf_wk_mode_set
*  Input: mode->WF_WK_MD_E
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
static WF_WK_MD_E g_mode = WWM_STATION;
int tuya_hal_wifi_set_work_mode(const WF_WK_MD_E mode)
{}

/***********************************************************
*  Function: wf_wk_mode_get
*  Input: none
*  Output: mode
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_work_mode(WF_WK_MD_E *mode)
{}

bool sniffer_on = FALSE;
bool is_sniffer_on()
{
   return 0;
}


static void sniffer_callback(unsigned char *buf, unsigned int len, void* userdata)
{
   return 0;
}



int tuya_hal_wifi_sniffer_set(const bool en, const SNIFFER_CALLBACK cb)
{}


#if defined(ENABLE_AP_FAST_CONNECT) && (ENABLE_AP_FAST_CONNECT==1)
/***********************************************************
*  Function: hwl_wf_fast_station_connect
*  Input: none
*  Output: fast_ap_info
*  Return: OPERATE_RET
***********************************************************/
int hwl_wf_get_connected_ap_info(FAST_WF_CONNECTED_AP_INFO_S *fast_ap_info)
{
    return OPRT_OK;
}

/***********************************************************
*  Function: hwl_wf_fast_station_connect
*  Input: ssid passwd
*  Output: mode
*  Return: OPERATE_RET
***********************************************************/
int hwl_wf_fast_station_connect(FAST_WF_CONNECTED_AP_INFO_S *fast_ap_info)
{
    return OPRT_OK;

}
#endif
/***********************************************************
*  Function: wf_station_connect
*  Input: ssid
*         passwd
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_connect(const char *ssid, const char *passwd)
{}

/***********************************************************
*  Function: wf_station_disconnect
*  Input: none
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_disconnect(void)
{}

/***********************************************************
*  Function: wf_station_get_conn_ap_rssi
*  Input: none
*  Output: rssi
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_get_conn_ap_rssi(int8_t *rssi)
{}

/***********************************************************
*  Function: wf_station_stat_get
*  Input: none
*  Output: stat
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_get_status(WF_STATION_STAT_E *stat)
{}

/***********************************************************
*  Function: wf_ap_start
*  Input: cfg
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_ap_start(const WF_AP_CFG_IF_S *cfg)
{
   return 0;
}


/***********************************************************
*  Function: wf_ap_stop
*  Input: none
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_ap_stop(void)
{
#if 0
	int ret;
	ret = mbed_lwip_stopap(0);
	#endif
    return 0;
}
static COUNTRY_CODE_E cur_country_code = COUNTRY_CODE_CN;
/***********************************************************
*  Function: hwl_wf_set_country_code
*  Input: none
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_set_country_code(const char *p_country_code)
{
   return 0;
}

u8 lp_rcnt = 0;

int tuya_hal_wifi_lowpower_disable(void)
{
   return 0;
}


int tuya_hal_wifi_lowpower_enable(void)
{
   return 0;
}


COUNTRY_CODE_E tuya_hal_wifi_get_cur_country_code(void)
{
   return 0;
}


bool tuya_hal_wifi_get_rf_cal_flag(void)
{
   return 0;
}


int tuya_hal_wifi_send_mgnt(const uint8_t *buf, const uint32_t len)
{
   return 0;
}


int tuya_hal_wifi_close_concurrent_ap(void)
{return 0;}

int tuya_hal_wifi_station_get_ap_mac(NW_MAC_S *mac)
{return 0;}

int tuya_hal_wifi_register_recv_mgnt_callback(bool enable, WIFI_REV_MGNT_CB recv_cb)
{return 0;}

int stat(const char *path, struct stat *buf)
{return 0;}


