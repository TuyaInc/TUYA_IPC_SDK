/***********************************************************
*  File: wifi_hwl.c
*  Author: nzy
*  Date: 20170914
***********************************************************/
#include "tuya_hal_wifi.h"
#include "wf_basic_intf.h"
#include "nsapi.h"
#include "lwip/netif.h"
#include "lwip/inet.h"


#include <string.h>
#include "uni_log.h"
#include "stdio.h"
#include "lwip_stack.h"
#include "FreeRTOS.h"
#include "rt_task.h"
#include "semphr.h"
#include "main.h"
#include <lwip_netconf.h>
#include "tcpip.h"
#include <wlan_test_inc.h>
#include <dhcp/dhcps.h>

#include "wifi_conf.h"
#include "wifi_util.h"

#include "tycam_qrcode.h"
#include "tycam_dev_mgt.h"


#define LOGD(...) printf("[WIFI DEBUG]" __VA_ARGS__)
#define LOGN(...) printf("[WIFI NOTICE]" __VA_ARGS__)
#define LOGI(...) printf("[WIFI INFO]" __VA_ARGS__)
#define LOGE(...) printf("[WIFI ERROR]" __VA_ARGS__)



#define IP_LEN 16
#define MAX_AP_SEARCH 30

BYTE_T sniffer_channel;


unsigned char tuya_mac_addr[6] = {0};

char tuya_ip_addr[4]    = {192, 168, 66, 1};
char tuya_msk_addr[4]   = {255, 255, 255, 0};
char tuya_gw_addr[4]    = {192, 168, 66, 1};
char tuya_dhcp_start[4] = {192, 168, 66, 100};
char tuya_dhcp_end[4] = {192, 168, 66, 255};

unsigned char tuya_wifi_state = WSS_IDLE;
extern struct netif lwip_sta_netif;
extern struct netif lwip_ap_netif;

//rda59xx_sta_info r_sta_info;
/***********************************************************
*************************micro define***********************
***********************************************************/

/***********************************************************
*************************variable define********************
***********************************************************/

STATIC CHAR_T g_scan_flag = 0;
STATIC UCHAR_T g_scan_num = 0; 
STATIC AP_IF_S *g_ap_ary = NULL;

rtw_result_t __scan_result_handler( rtw_scan_handler_result_t* malloced_scan_result )
{
	if (malloced_scan_result->scan_complete != RTW_TRUE) 
	{
	    if(g_scan_num >= MAX_AP_SEARCH)
	    {
            return;
	    }
		rtw_scan_result_t* record = &malloced_scan_result->ap_details;
		record->SSID.val[record->SSID.len] = 0; /* Ensure the SSID is null terminated */
        
        strncpy(g_ap_ary[g_scan_num].ssid, record->SSID.val, WIFI_SSID_LEN+1);
        memcpy(g_ap_ary[g_scan_num].bssid, record->BSSID.octet, 6);       
        g_ap_ary[g_scan_num].channel = record->channel;
        g_ap_ary[g_scan_num].rssi = record->signal_strength;
        g_ap_ary[g_scan_num].s_len= record->SSID.len;
        ++g_scan_num;
	} 
	else
	{
		g_scan_flag = 1;
	}

    printf("\n[TUYA]scan result.\n");
	return RTW_SUCCESS;
}

/***********************************************************
*  Function: wf_all_ap_scan
*  Input: none
*  Output: ap_ary->scan ap info array
*          num->scan ap nums
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_all_ap_scan(AP_IF_S **ap_ary, uint32_t *num)
{
    int cnt = 0;
    char ssid[32] = {0};

    OUT ;

    if(NULL == ap_ary || NULL == num) {
        return OPRT_INVALID_PARM;
    }

    g_ap_ary = *ap_ary = tuya_hal_internal_malloc(sizeof(AP_IF_S) * MAX_AP_SEARCH);
    memset(g_ap_ary, 0, sizeof(AP_IF_S) * MAX_AP_SEARCH);
    
    g_scan_flag = 0;
    g_scan_num = 0;
    if(wifi_scan_networks(__scan_result_handler, NULL ) != RTW_SUCCESS){
		printf("\n\rERROR: wifi scan failed\n");
	}

	while(!g_scan_flag)
	{
        tuya_hal_system_sleep(500);
	}
	
	*num = g_scan_num;
	g_scan_flag = 0;
    g_scan_num = 0;

    LOGI("scan finish\r\n");
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_assign_ap_scan
*  Input: ssid->assign ap ssid
*  Output: ap->ap info
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_assign_ap_scan(const char *ssid, AP_IF_S **ap)
{
		#if 0
	int cnt = 0;
	int num = 0;
	int i,ret;

    rda59xx_scan_result *bss_list;
	rda59xx_scan_result *_bss_list;
	rda59xx_scan_info r_scan_info;
	OUT AP_IF_S *_ap_ary;

    if(NULL == ssid || \
       NULL == ap) {
        return OPRT_INVALID_PARM;
    }

	memset(&r_scan_info, 0, sizeof(rda59xx_scan_info));
	strcpy((char*)r_scan_info.SSID, ssid);
	r_scan_info.SSID_len = strlen(ssid);
	r_scan_info.channel = 0;
    cnt = mbed_lwip_scan_inf(&r_scan_info);
	if(cnt <= 0) {
        LOGE("dont find ap(%s) %d",ssid,cnt);
        return OPRT_COM_ERROR;
	}

    _bss_list = (rda59xx_scan_result *)malloc(cnt * sizeof(rda59xx_scan_result));
	bss_list = _bss_list;
	if (_bss_list == NULL) {
		LOGI("malloc buf fail");
		return OPRT_MALLOC_FAILED;
	}
    memset(_bss_list, 0, cnt * sizeof(rda59xx_scan_result));
	num = mbed_lwip_get_scan_result(_bss_list, cnt);
	LOGN("num %d cnt %d",num,cnt);

  	for(i = 0;i <num;i++) {
        ret = strcmp((const char *)(_bss_list->SSID), (const char *)ssid);
		if(ret ==0)
			break;
        _bss_list++;
    }

	if(i == num) {
        LOGE("dont find ap(%s)",ssid);
        free(bss_list);
        return OPRT_COM_ERROR;
	}
    _ap_ary = *ap = malloc(sizeof(AP_IF_S));
    memcpy(_ap_ary->ssid,_bss_list->SSID,33);
    _ap_ary->s_len = _bss_list->SSID_len;
    _ap_ary->channel = _bss_list->channel;
    _ap_ary->rssi = _bss_list->RSSI;
    memcpy(_ap_ary->bssid,_bss_list->BSSID,6);

	if(bss_list){
    	free(bss_list);
	}

    rda59xx_del_scan_all_result();
	#endif
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_release_ap
*  Input: ap
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_release_ap(AP_IF_S *ap)
{

    if(NULL == ap) {
        return OPRT_INVALID_PARM;
    }

   tuya_hal_internal_free((void *)ap);
   return OPRT_OK;
}

/***********************************************************
*  Function: wf_set_cur_channel
*  Input: chan
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
static BYTE_T g_chan = 0;
int tuya_hal_wifi_set_cur_channel(const uint8_t chan)
{
    if(g_chan == 0)
    {
        return OPRT_OK;
    }

	if(wifi_set_channel(chan) == 0)
	{
        printf("Set Channel:%d\n",chan);
	}
	sniffer_channel = chan;

    return OPRT_OK;
}

/***********************************************************
*  Function: wf_get_cur_channel
*  Input: none
*  Output: chan
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_cur_channel(uint8_t *chan)
{
    if(NULL == chan) {
        return OPRT_INVALID_PARM;
    }
    *chan = sniffer_channel;

    return OPRT_OK;
}

/***********************************************************
*  Function: wf_sniffer_set
*  Input: en->TRUE/FALSE
*         cb->sniffer callback
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
static VOID (*frame_cb)(IN CONST BYTE_T *buf,IN CONST USHORT_T len) = NULL;
#define SUPPORT_LDPC_PATTERN_MIMO 1
static int my_smartconfig_handler(void *data,unsigned short data_len)
{
    if (frame_cb) {
        if (NULL == data) {
#if SUPPORT_LDPC_PATTERN_MIMO
            if (data_len != 0 ) {
                WLAN_FRAME_S wl_frm;
                memset(&wl_frm, 0, SIZEOF(WLAN_FRAME_S));
                wl_frm.frame_type = WFT_MIMO_DATA;
                wl_frm.frame_data.mimo_info.rssi = -40;
                wl_frm.frame_data.mimo_info.len = data_len;
                wl_frm.frame_data.mimo_info.channel = sniffer_channel;
                wl_frm.frame_data.mimo_info.type = MIMO_TYPE_LDPC;
                wl_frm.frame_data.mimo_info.mcs = 1;
                frame_cb(&wl_frm, wl_frm.frame_data.mimo_info.len);
            }
#endif
        } else {
            frame_cb(data, data_len);
        }
    }
    return 0;
}

/***********************************************************
*  Function: wf_get_ip
*  Input: wf->WF_IF_E
*  Output: ip
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_ip(const WF_IF_E wf, NW_IP_S *ip)
{
    extern struct netif *netif_list;
    struct netif *pnetif = netif_list;

    if(wf == WF_AP)
    {
        //not support ap mode!
        return OPRT_COM_ERROR;
    }

    while(pnetif)
    {
        //eth: en  wifi:r0
        if(pnetif->name[0] == 'r' && pnetif->name[1] == '0')
        {
            if(pnetif->ip_addr.addr == 0)
            {
                return OPRT_COM_ERROR;
            }
            strncpy(ip->ip, ipaddr_ntoa(&pnetif->ip_addr), 16);
            strncpy(ip->mask, ipaddr_ntoa(&pnetif->netmask), 16);
            strncpy(ip->gw, ipaddr_ntoa(&pnetif->gw), 16);

            return OPRT_OK;
        }
        else
        {
            pnetif = pnetif->next;
        }
    }
	//LOGI("hwl_wf_get_ip\r\n");
    return OPRT_COM_ERROR;
}

/***********************************************************
*  Function: wf_get_mac
*  Input: wf->WF_IF_E
*  Output: mac
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_mac(const WF_IF_E wf, NW_MAC_S *mac)
{
	#if 0
    if(NULL == mac) {
        return OPRT_INVALID_PARM;
    }

    rda59xx_get_macaddr(mac->mac, WF_STATION);
    //LOGI("hwl_wf_get_mac,%02x:%02x:%02x:%02x:%02x:%02x\r\n",mac->mac[0],mac->mac[1],mac->mac[2],mac->mac[3],mac->mac[4],mac->mac[5]);
	#endif
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_set_mac
*  Input: wf->WF_IF_E
*         mac
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_set_mac(const WF_IF_E wf, const NW_MAC_S *maca)
{
	#if 0
	char *mdata, mac[6], i;

	mdata = &(maca->mac[0]);

    if(!mac_is_valid(maca->mac)){
        LOGI("mac if valid\r\n");
        return -1;
    }

    memcpy(tuya_mac_addr, maca->mac, 6);

	//LOGI("%02x:%02x:%02x:%02x:%02x:%02x\r\n",maca->mac[0],maca->mac[1],maca->mac[2],maca->mac[3],maca->mac[4],maca->mac[5]);
    rda59xx_set_macaddr(tuya_mac_addr, 0);
	#endif
    LOGI("hwl_wf_set_mac\r\n");
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_wk_mode_set
*  Input: mode->WF_WK_MD_E
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
static WF_WK_MD_E g_mode = WWM_STATION;
int tuya_hal_wifi_set_work_mode(const WF_WK_MD_E mode)
{
    int tmp_mode;
    wext_get_mode(WLAN0_NAME, &tmp_mode);

    if(tmp_mode == IW_MODE_INFRA)
    {
        if(mode == WWM_SNIFFER)
        {
             wifi_init_packet_filter();//??是否需要free
             wifi_enter_promisc_mode();
             g_mode = WWM_SNIFFER;
             return OPRT_OK;
        }
        else if(mode == WWM_STATION)
        {
            g_mode = WWM_STATION;
            return OPRT_OK;
        }
        else
        {
            //NOT SUPPORT 
            return OPRT_COM_ERROR;
        }
    }
    else if(tmp_mode == IW_MODE_MONITOR)
    {
        if(mode == WWM_STATION)
        {
            wifi_set_promisc(RTW_PROMISC_DISABLE, NULL, 0);
            g_mode = WWM_STATION;
            return OPRT_OK;
        }
        else if(mode == WWM_SNIFFER)
        {
            g_mode = WWM_SNIFFER;
            return OPRT_OK;
        }
        else
        {
            return OPRT_COM_ERROR;
        }
    }
    else if(tmp_mode == IW_MODE_AUTO)
    {
        if(g_mode == mode)
        {
            return OPRT_OK;
        }
        if(mode == WWM_SNIFFER && g_mode == WWM_STATION)
        {
             wifi_init_packet_filter();//??是否需要free
             wifi_enter_promisc_mode();
             g_mode = WWM_SNIFFER;
             return OPRT_OK;
        }
        else if(mode == WWM_STATION && g_mode == WWM_SNIFFER)
        {
            wifi_set_promisc(RTW_PROMISC_DISABLE, NULL, 0);
            g_mode = WWM_STATION;
            return OPRT_OK;
        }
        else
        {
            //NOT SUPPORT 
            return OPRT_COM_ERROR;
        }

    }
     

    printf("mode[%d] not support!\n", mode);
    return OPRT_COM_ERROR;
}

/***********************************************************
*  Function: wf_wk_mode_get
*  Input: none
*  Output: mode
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_get_work_mode(WF_WK_MD_E *mode)
{
    int tmp_mode;
    wext_get_mode(WLAN0_NAME, &tmp_mode);
    if(tmp_mode == IW_MODE_MASTER)
    {
        *mode = WWM_SOFTAP;
    }
    else if(tmp_mode == IW_MODE_INFRA)
    {
        *mode = WWM_STATION;
    }
    else if(tmp_mode == IW_MODE_MONITOR)
    {
        *mode = WWM_SNIFFER;
    }
    else
    {
        if(tmp_mode == IW_MODE_AUTO)
        {
            *mode = g_mode;
            return OPRT_OK;
        }
        return OPRT_COM_ERROR;
    }

    return OPRT_OK;
}

static BOOL_T sniffer_on = FALSE;
BOOL_T is_sniffer_on()
{
    return sniffer_on;
}

static void sniffer_callback(unsigned char *buf, unsigned int len, void* userdata)
{
    //printf("get data:%d\n",len);
    /*int i = 0;
    for(i; i< len;i++)
    {
        printf("%2x ", buf[i]);
        if(!(i % 32))
        {
            printf("\n");
        }
    }
	printf("\n");*/

	if(buf)
	{
        frame_cb(buf ,len);
	}
	//printf("release data:%d\n",len);
}


int tuya_hal_wifi_sniffer_set(const bool en, const SNIFFER_CALLBACK cb)
{
    if(en) {
        frame_cb = cb;
        g_chan = 1;
        tuya_hal_wifi_set_work_mode(WWM_SNIFFER);

        wifi_set_promisc(RTW_PROMISC_ENABLE_2, sniffer_callback, FALSE);

        tycam_qrcode_start();
        tycam_dev_status(TYCAM_DEV_STATUS_WAIT_CNT_NET);
    }else {
        g_chan = 0;
        tuya_hal_wifi_set_work_mode(WWM_STATION);
        frame_cb = NULL;
        tycam_qrcode_stop();
        tycam_dev_status(TYCAM_DEV_STATUS_GET_CONFIG_INFO);
    }

    return OPRT_OK;
}


#if defined(ENABLE_AP_FAST_CONNECT) && (ENABLE_AP_FAST_CONNECT==1)
/***********************************************************
*  Function: hwl_wf_fast_station_connect
*  Input: none
*  Output: fast_ap_info
*  Return: OPERATE_RET
***********************************************************/
int hwl_wf_get_connected_ap_info(FAST_WF_CONNECTED_AP_INFO_S *fast_ap_info)
{
    return OPRT_OK;
}

/***********************************************************
*  Function: hwl_wf_fast_station_connect
*  Input: ssid passwd
*  Output: mode
*  Return: OPERATE_RET
***********************************************************/
int hwl_wf_fast_station_connect(FAST_WF_CONNECTED_AP_INFO_S *fast_ap_info)
{
    return OPRT_OK;

}
#endif
/***********************************************************
*  Function: wf_station_connect
*  Input: ssid
*         passwd
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_connect(const char *ssid, const char *passwd)
{
	int ret = RTW_ERROR;
	unsigned long tick1 = xTaskGetTickCount();
	unsigned long tick2, tick3;
	rtw_security_t	security_type;
	char 				*password;
	int 				ssid_len;
	int 				password_len;
	int 				key_id;
	void				*semaphore;

    if(ssid != NULL && 0 != strlen(ssid) )
    {
        if (passwd != NULL && 0 != strlen(passwd)) 
        {
            security_type = RTW_SECURITY_WPA2_AES_PSK;
            password = passwd;
            ssid_len = strlen(ssid);
            password_len = strlen(password);
            key_id = 0;
            semaphore = NULL;
        }
        else
        {
            security_type = RTW_SECURITY_OPEN;
            password = NULL;
            ssid_len = strlen(ssid);
            password_len = 0;
            key_id = 0;
            semaphore = NULL;
        }

        /* set auto reconnect here */
        wifi_set_autoreconnect(1);

        ret = wifi_connect(ssid, 
                        security_type, 
                        password, 
                        ssid_len, 
                        password_len, 
                        key_id,
                        semaphore);

        if(ret != RTW_SUCCESS)
        {
            printf("\n\rERROR: Operation failed!");
            return OPRT_OK;
        } 

        tick2 = xTaskGetTickCount();
        printf("\r\nConnected after %dms.\n", ((int)tick2-(int)tick1));
        LwIP_DHCP(0, DHCP_S_START);

        tick3 = xTaskGetTickCount();
        printf("\r\n\nGot IP after %dms.\n", ((int)tick3-(int)tick1));        
    }

	return OPRT_OK;
}

/***********************************************************
*  Function: wf_station_disconnect
*  Input: none
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_disconnect(void)
{
	wifi_disconnect();
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_station_get_conn_ap_rssi
*  Input: none
*  Output: rssi
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_get_conn_ap_rssi(int8_t *rssi)
{
    int result = 0;
    int ret = 0;
    
    ret = wifi_get_rssi(&result);
    if(ret != RTW_SUCCESS)
    {
        printf("%s get rssi failed!ret = %d\n",__func__, ret);
        return OPRT_COM_ERROR;
    }

    *rssi = result;
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_station_stat_get
*  Input: none
*  Output: stat
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_station_get_status(WF_STATION_STAT_E *stat)
{
	unsigned char ssid[33];
    NW_IP_S ip = {0};

    int ret = tuya_hal_wifi_get_ip(0, &ip);
    if(ret == 0)
    {
        *stat = WSS_GOT_IP;
        return OPRT_OK;
    }
    if(wext_get_ssid(WLAN0_NAME, ssid) > 0)
    {
        *stat = WSS_CONN_SUCCESS; 
        return OPRT_OK;
    }

    *stat = WSS_IDLE;
    return OPRT_OK;
}

/***********************************************************
*  Function: wf_ap_start
*  Input: cfg
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_ap_start(const WF_AP_CFG_IF_S *cfg)
{
#if 0
	int ret;
	rda59xx_ap_info r_ap_info;
	char addrtemp[NSAPI_IPv4_SIZE];

	if(NULL == cfg) {
        return OPRT_INVALID_PARM;
    }

	LOGI("ssid=%s,passwd=%s,channel=%d,ssid_hidden=%d\r\n",(char *)cfg->ssid,(char *)cfg->passwd,cfg->chan,cfg->ssid_hidden);

    //Start AP
    memset((void*)&r_ap_info, 0, sizeof(rda59xx_ap_info));
	memcpy(r_ap_info.ssid, (char *)cfg->ssid, strlen((char *)cfg->ssid));
    memcpy(r_ap_info.pw, (char *)cfg->passwd, strlen((char *)cfg->passwd));
    r_ap_info.ssid[strlen((char *)cfg->ssid)] = r_ap_info.pw[strlen((char *)cfg->passwd)] = '\0';
	if (cfg->chan>0 && cfg->chan<14) {
        r_ap_info.channel = (unsigned char)cfg->chan;
    }
	else {
		r_ap_info.channel = 1;	//must set a default value
	}
    r_ap_info.hidden = cfg->ssid_hidden;
	r_ap_info.link_num = 1;	//tuya default request to set 1, if not set default connect 8

    memcpy(addrtemp, inet_ntoa(*(unsigned int *)tuya_ip_addr), NSAPI_IPv4_SIZE);
    r_ap_info.ip = inet_addr(addrtemp);
    memcpy(addrtemp, inet_ntoa(*(unsigned int *)tuya_msk_addr), NSAPI_IPv4_SIZE);
	r_ap_info.netmask = inet_addr(addrtemp);
    memcpy(addrtemp, inet_ntoa(*(unsigned int *)tuya_gw_addr), NSAPI_IPv4_SIZE);
    r_ap_info.gateway= inet_addr(addrtemp);
    memcpy(addrtemp, inet_ntoa(*(unsigned int *)tuya_dhcp_start), NSAPI_IPv4_SIZE);
    r_ap_info.dhcps= inet_addr(addrtemp);
    memcpy(addrtemp, inet_ntoa(*(unsigned int *)tuya_dhcp_end), NSAPI_IPv4_SIZE);
    r_ap_info.dhcpe= inet_addr(addrtemp);

	ret = mbed_lwip_startap_inf(&r_ap_info);
	#endif
    return 0;
}

/***********************************************************
*  Function: wf_ap_stop
*  Input: none
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_ap_stop(void)
{
#if 0
	int ret;
	ret = mbed_lwip_stopap(0);
	#endif
    return 0;
}
static COUNTRY_CODE_E cur_country_code = COUNTRY_CODE_CN;
/***********************************************************
*  Function: hwl_wf_set_country_code
*  Input: none
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
int tuya_hal_wifi_set_country_code(const char *p_country_code)
{
	#if 0
    LOGD("#set country code:%s#", p_country_code);
    if (!strcmp(p_country_code, "JP")) {
        rda59xx_set_country_code(JP);
        cur_country_code = COUNTRY_CODE_JP;
    }else if (!strcmp(p_country_code, "US")) {
        rda59xx_set_country_code(NA);
        cur_country_code = COUNTRY_CODE_US;
    }else {
        rda59xx_set_country_code(EU);
        cur_country_code = COUNTRY_CODE_EU;
    }
#endif
    return OPRT_OK;
}
static UINT_T lp_rcnt = 0;

int tuya_hal_wifi_lowpower_disable(void)
{
	#if 0
    if(!tuya_get_lp_mode()) {
        //LOGE("it's in normal mode");
        return OPRT_COM_ERROR;
    }

    if(!lp_rcnt++) {
        //pmu_acquire_wakelock(PMU_DEV_USER_BASE); //acquire wakelock
    }
	#endif

    return OPRT_OK;
}

int tuya_hal_wifi_lowpower_enable(void)
{
	#if 0
    if(!tuya_get_lp_mode()) {
        //LOGE("it's in normal mode");
        return OPRT_COM_ERROR;
    }

    if(lp_rcnt > 0) {
        lp_rcnt--;
    }

    if(!lp_rcnt) {
        //pmu_release_wakelock(PMU_DEV_USER_BASE);
    }
#endif
    return OPRT_OK;
}

COUNTRY_CODE_E tuya_hal_wifi_get_cur_country_code(void)
{
    return cur_country_code;
}

bool tuya_hal_wifi_get_rf_cal_flag(void)
{
	#if 0
    int ret = 0;    
    unsigned int calflag = 0;
    ret = rda5981_flash_read_cal_flag(&calflag);
    if (ret != 0) {
        LOGD("read cal flag fail");
        return FALSE;  
    }     
    LOGD("read cal flag sucess is %d", calflag);
    if (calflag) {
        return TRUE;
    } else {
        return FALSE;
    }
	#endif
	return FALSE;
}

int tuya_hal_wifi_send_mgnt(const uint8_t *buf, const uint32_t len)
{
    return -1;
}
