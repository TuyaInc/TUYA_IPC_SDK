
#include "tuya_hal_memory.h"
#include "tuya_hal_system_internal.h"
#include "tuya_hal_mutex.h"

#include "tlsf.h"
/***********************************************************
*************************micro define***********************
***********************************************************/

/***********************************************************
*************************variable define********************
***********************************************************/
static TUYA_MALLOC_FUNC_T s_internal_malloc_func = NULL;
static TUYA_FREE_FUNC_T   s_internal_free_func   = NULL;

/***********************************************************
*************************function define********************
***********************************************************/
static tlsf_t g_tlsf = NULL;
static MUTEX_HANDLE s_tlsf_lock = NULL;

//static void *stp[2048] ={0};

void check_stp()
{}
int __tuya_tlsf_init_pool()
{
    int size = 8*1024*1024 - 512*1024;
    //int size = 5*1024*1024;
    char * mem = malloc(size);
    if(mem == NULL)
    {
        printf("%s failed\n",__func__);
        return -1;
    }
    memset(mem, 0 , size);
    g_tlsf = tlsf_create_with_pool(mem, size);
    return 0;
}

int __tuya_tlsf_init_mutex()
{
    int ret = tuya_hal_mutex_create_init(&s_tlsf_lock);
    if (ret != 0) {
        printf("%s mutex fail\n",__func__);
        return -1;
    }
    return 0;
}

int tuya_tlsf_init()
{
    if(__tuya_tlsf_init_pool() != 0)
    {
        return -1;
    }
    if(__tuya_tlsf_init_mutex() != 0)
    {
        return -1;
    }

    return 0;
}
void *tuya_hal_system_malloc(const size_t size)
{
    void * p = NULL;
    if(!g_tlsf)
    {
        return NULL;
    }

    tuya_hal_mutex_lock(s_tlsf_lock);
    p = tlsf_malloc(g_tlsf, size);
    if (p ==NULL)
    {
        printf("p == NULL\n");
    }

    tuya_hal_mutex_unlock(s_tlsf_lock);
    return p;
}

void tuya_hal_system_free(void* ptr)
{
    unsigned int return_addr = 0;

    asm("move %0, $ra\n"
        : "=r" (return_addr));

    if(!g_tlsf)
    {
        return;
    }

    if (ptr == NULL)
    {
        return;
    }

    tuya_hal_mutex_lock(s_tlsf_lock);
    //printf("FREE :%p\n", ptr);
    //free_stp(ptr, return_addr);
    tlsf_free(g_tlsf, ptr);
    tuya_hal_mutex_unlock(s_tlsf_lock);
}

void *tuya_hal_system_calloc(size_t numitems, size_t size)
{
    size_t sizel = numitems * size;

    void *ptr = tuya_hal_system_malloc(sizel);
    if (ptr == NULL)
    {
        printf("ptr == NULL\n");
        return NULL;
    }

    memset(ptr, 0, sizel);
    return ptr;
}

void* tuya_hal_system_realloc(void *ptr, size_t size)
{
    void *p = NULL;
    if(!g_tlsf)
    {
        return NULL;
    }
    
    tuya_hal_mutex_lock(s_tlsf_lock);
    if (ptr == NULL)
    {
        p = tlsf_realloc(g_tlsf, ptr,size);
    }
    else
    {
        p = tlsf_realloc(g_tlsf, ptr,size);
    }
    tuya_hal_mutex_unlock(s_tlsf_lock);

    return p;
}


int tuya_hal_set_mem_func(TUYA_MALLOC_FUNC_T malloc_func, TUYA_FREE_FUNC_T free_func)
{

    s_internal_malloc_func = malloc_func;
    s_internal_free_func = free_func;
    return 0;
}

void* tuya_hal_internal_malloc(const size_t size)
{
    if (s_internal_malloc_func) {
        return s_internal_malloc_func(size);
    } else {
        return tuya_hal_system_malloc( size);
    }
}

void tuya_hal_internal_free(void* ptr)
{
    if (s_internal_free_func)
    {
        s_internal_free_func(ptr);
    }
    else
    {
        tuya_hal_system_free(ptr);
    }
}

