#include "tuya_hal_fs.h"
#include "rt_fs.h"
#include "ff.h"

typedef struct {
    DIR tuya_dir;
    FILINFO tuya_filenfo;
} TUYADIR_S;

typedef struct _tuya_Opt_FIL_
{
    FIL opt_file;           //操作文件句柄;
    int32_t index_offset;  //文件offset位置;
}tuya_Opt_FIL;

int tuya_hal_fs_mkdir(const char* path)
{
    return rt_fs_mkdir_to_path((char*)path);
}

int tuya_hal_fs_remove(const char* path)
{
    return rt_fs_rm(path);
}

int tuya_hal_fs_mode(const char* path, uint32_t* mode)
{
    FILINFO fno = {0};
    int ret;
    
    if(strcmp(path, "/") == 0)
    {
        *mode |= TUYA_IRUSR;
        *mode |= TUYA_IWUSR;
        return 0;
    }
    
    if (ret = rt_f_stat(path, &fno) != 0)
    {
        return -1;
    }

    if (fno.fattrib & AM_DIR)
    {
        *mode |= TUYA_IXUSR;
    }

    if (fno.fattrib & AM_RDO)
    {
		*mode |= TUYA_IRUSR;
    }
    else
    {
        *mode |= TUYA_IRUSR;
        *mode |= TUYA_IWUSR;
    }

    return 0;
}

int tuya_hal_fs_is_exist(const char* path, bool* is_exist)
{
   *is_exist = rt_fs_is_exist(path);
   return 0;
}

int tuya_hal_dir_open(const char* path, TUYA_DIR* dir)
{
    TUYADIR_S *tuyadirbak = (TUYADIR_S *)tuya_hal_internal_malloc(sizeof(TUYADIR_S));
	if(tuyadirbak == 0)
    {
        printf("%s %d open error, malloc failed\n",__func__,__LINE__);
        return -1;
    }
	
    memset(tuyadirbak, 0 ,sizeof(TUYADIR_S));
    if (f_opendir(&(tuyadirbak->tuya_dir), path) != 0)
    {
        printf("%s %d open error.\n",__func__,__LINE__);
        tuya_hal_internal_free(tuyadirbak);
		return -1;
    }

    *dir = (TUYA_DIR *)tuyadirbak;

    return 0;
}

int tuya_hal_dir_close(TUYA_DIR dir)
{
    if(dir == NULL)
    {
        return -1;
    }
    TUYADIR_S *tuyadirbak = (TUYADIR_S *)dir;
    if (f_closedir(&(tuyadirbak->tuya_dir)) != 0)
    {
        printf("%s %d close error\n",__func__,__LINE__);
        tuya_hal_internal_free(tuyadirbak);
        if((tuyadirbak->tuya_filenfo).lfname)
        {
            tuya_hal_internal_free((tuyadirbak->tuya_filenfo).lfname);
			(tuyadirbak->tuya_filenfo).lfname = NULL;
        }
        return -1;
    }

    tuya_hal_internal_free(tuyadirbak);
    if((tuyadirbak->tuya_filenfo).lfname)
    {
        tuya_hal_internal_free((tuyadirbak->tuya_filenfo).lfname);
		(tuyadirbak->tuya_filenfo).lfname = NULL;
    }

    return 0;
}

int tuya_hal_dir_read(TUYA_DIR dir, TUYA_FILEINFO* info)
{
    TUYADIR_S *tuyadirbak = (TUYADIR_S *)dir;

    if((tuyadirbak->tuya_filenfo).lfname == NULL)
    {
        (tuyadirbak->tuya_filenfo).lfname = (char *)tuya_hal_internal_malloc(sizeof(char) * MAX_PATH);
		if((tuyadirbak->tuya_filenfo).lfname == NULL)
        {
            return -1;
        }
    }
    (tuyadirbak->tuya_filenfo).lfsize = MAX_PATH;
    
    *info = &(tuyadirbak->tuya_filenfo);
    if (f_readdir(&(tuyadirbak->tuya_dir), &(tuyadirbak->tuya_filenfo)) != 0 || (tuyadirbak->tuya_filenfo).fname[0] == 0)
    {
        return -1;
    }

    return 0;
}

int tuya_hal_dir_name(TUYA_FILEINFO info, const char** name)
{
    FILINFO *infobak;
    infobak = (FILINFO *)info;
    *name = *((*infobak).lfname) ? (*infobak).lfname :  (*infobak).fname;
    return 0;
}

int tuya_hal_dir_is_directory(TUYA_FILEINFO info, bool* is_dir)
{
    FILINFO *infobak = (FILINFO *)info;
    *is_dir = infobak->fattrib & AM_DIR;
    
    return 0;
}

int tuya_hal_dir_is_regular(TUYA_FILEINFO info, bool* is_regular)
{
    FILINFO *infobak;
    infobak = (FILINFO *)info;
    if (!((*infobak).fattrib & AM_DIR))
    {
         *is_regular = TRUE;
    }

    return 0;
}

int tuya_hal_fs_rename(char *path_old,char *path_new)
{
    char    src_path[256] ={0};
    char    dst_path[256] = {0};

    rt_fs_path_from_user(path_old, src_path);
    rt_fs_path_from_user(path_new, dst_path);

    return rt_fs_rename (src_path, dst_path);
}

TUYA_FILE tuya_hal_fopen(const char* path, const char* mode)
{
    BYTE _mode = 0;

    if(strstr(mode, "a") || strstr(mode, "w"))
    {
        _mode = FA_WRITE | FA_OPEN_ALWAYS;
    }
    else
    {
        _mode = FA_READ;
    }

    tuya_Opt_FIL *file = tuya_hal_internal_malloc(sizeof(tuya_Opt_FIL));
	if(file == NULL)
    {
        return NULL;
    }

    if (rt_f_open(&file->opt_file, path, _mode) != RT_OK)
    {
        tuya_hal_internal_free(file);
        return NULL;
    }

    file->index_offset = 0;

    if(strstr(mode, "a"))
    {
        if(rt_f_lseek(&file->opt_file,  rt_f_size(&file->opt_file)) != RT_OK)
        {
            tuya_hal_fclose((TUYA_FILE)file);
            file = NULL;
        }
        else
        {
            file->index_offset = rt_f_size(&file->opt_file);    //位置移动置最后面;
        }
    }

    return (TUYA_FILE)file;
}

int tuya_hal_fclose(TUYA_FILE file)
{
    if(file)
    {
        rt_f_close(&((tuya_Opt_FIL *)file)->opt_file);
        tuya_hal_internal_free(file);
    }

    return 0;
}

int tuya_hal_fread(void* buf, int bytes, TUYA_FILE file)
{
    unsigned int num = 0;
    tuya_Opt_FIL *pfile = (tuya_Opt_FIL *)file;
    rt_f_read((RT_FILE*)&pfile->opt_file, buf, (unsigned int)bytes, &num);
    if(num)
    {
       pfile->index_offset+= num;   //记录当前读取文件指针的位置;
       return num;
    }

    return -1;
}

int tuya_hal_fwrite(void* buf, int bytes, TUYA_FILE file)
{
    int num = 0;
    int ret = 0;
    tuya_Opt_FIL *pfile = (tuya_Opt_FIL *)file;
    ret = rt_f_write((RT_FILE*)&pfile->opt_file, buf, bytes, &num);
    if(ret != 0)
    {
       return -1;
    }

    pfile->index_offset+= num;   //记录当前写入文件指针的位置;
    return num;
}

int tuya_hal_fsync(TUYA_FILE file)
{
    tuya_Opt_FIL *pfile = (tuya_Opt_FIL *)file;
    return f_sync((RT_FILE*)&pfile->opt_file);
}

char* tuya_hal_fgets(char* buf, int len, TUYA_FILE file)
{
    tuya_Opt_FIL *pfile = (tuya_Opt_FIL *)file;
    pfile->index_offset+= len;
    return (char*)rt_f_gets((RT_FILE*)&pfile->opt_file, (TCHAR*)buf, len);
}

int tuya_hal_feof(TUYA_FILE file)
{
    tuya_Opt_FIL *pfile = (tuya_Opt_FIL *)file;
    return rt_f_eof((RT_FILE*)&pfile->opt_file);
}

int tuya_hal_fseek(TUYA_FILE file, int32_t offs, int whence)
{
    if (file == NULL)
        return 0;

    tuya_Opt_FIL *pfile = (tuya_Opt_FIL *)file;
    int n_ret = 0;

    //根据操作文件的标志进行处理.
    if (whence == TUYA_SEEK_SET)
    {
        if (offs < 0)
        {
            return -1;  //文件头，不能再向前移动了.
        }

	//printf("%s %d ----seek-set offset:%d.\n",__func__,__LINE__,offs);
        //移动指针到开始位置.+offset.
        n_ret = rt_f_lseek((RT_FILE*)&pfile->opt_file, offs);
        if (n_ret != 0)
        {
            return n_ret;
        }

        pfile->index_offset = offs; //移动至开始位置的偏移;
        return n_ret;
    }
    else if (whence == TUYA_SEEK_CUR)
    {
        //移动指针到指定位置.由于平台没有当前位置指针.
        int m_mov_offset = pfile->index_offset + offs;
        if (m_mov_offset < 0)
        {
            return -1;
        }

	//printf("%s %d ----seek-cur offset:%d.\n",__func__,__LINE__,m_mov_offset);
        n_ret = rt_f_lseek((RT_FILE*)&pfile->opt_file, m_mov_offset);
        if (n_ret != 0)
        {
            return n_ret;
        }

        pfile->index_offset = m_mov_offset; //移动至新的偏移;
        return n_ret;
    }
    else if (whence == TUYA_SEEK_END)
    {
        //移动至文件结束位置.
        int m_mov_offset = rt_f_size((RT_FILE*)&pfile->opt_file) + offs;
        if (m_mov_offset < 0)
        {
            return -1;
        }

	//printf("%s %d ----seek-end offset:%d.\n",__func__,__LINE__,m_mov_offset);
        n_ret = rt_f_lseek((RT_FILE*)&pfile->opt_file, m_mov_offset);
        if (n_ret != 0)
        {
            return n_ret;
        }

        pfile->index_offset = m_mov_offset; //移动至新的偏移;
        return n_ret;
    }
}

int64_t tuya_hal_ftell(TUYA_FILE file)
{
    tuya_Opt_FIL *pfile = (tuya_Opt_FIL *)file;
    return rt_f_tell((RT_FILE*)&pfile->opt_file);
}

