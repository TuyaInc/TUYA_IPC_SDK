/***********************************************************
*  File: uni_mutex.c
*  Author: nzy
*  Date: 120427
***********************************************************/
#define _UNI_MUTEX_GLOBAL
//#include "rda_sys_wrapper.h"
#include "cmsis_os.h"
#include "tuya_hal_mutex.h"
#include "tuya_hal_system_internal.h"
#include "../errors_compat.h"
#include "lwip/sys.h"


/***********************************************************
*************************micro define***********************
***********************************************************/
typedef void * THRD_MUTEX;

typedef struct
{
    THRD_MUTEX mutex;
}MUTEX_MANAGE,*P_MUTEX_MANAGE;

#ifndef os_printf
#define os_printf printf
#endif

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

/***********************************************************
*  Function: CreateMutexAndInit 创建一个互斥量并初始化
*  Input: none
*  Output: pMutexHandle->新建的互斥量句柄
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_mutex_create_init(MUTEX_HANDLE *pMutexHandle)
{

    if(!pMutexHandle)
        return OPRT_INVALID_PARM;

    sys_mutex_t *sys_mutex = NULL;
    sys_mutex = (sys_mutex_t *)tuya_hal_internal_malloc(sizeof(sys_mutex_t));
    if(!(sys_mutex))
        return OPRT_MALLOC_FAILED;
        
	sys_mutex_new(sys_mutex);
	
	if (sys_mutex->id == NULL)
        return OPRT_INIT_MUTEX_FAILED;

    *pMutexHandle = (MUTEX_HANDLE *)sys_mutex;

    return OPRT_OK;
}

/***********************************************************
*  Function: MutexLock 加锁
*  Input: mutexHandle->互斥量句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_mutex_lock(const MUTEX_HANDLE mutexHandle)
{
    if(!mutexHandle)
        return OPRT_INVALID_PARM;

    sys_mutex_lock((sys_mutex_t *)mutexHandle);

    return OPRT_OK;
}

/***********************************************************
*  Function: MutexUnLock 解锁
*  Input: mutexHandle->互斥量句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_mutex_unlock(const MUTEX_HANDLE mutexHandle)
{
    if(!mutexHandle)
        return OPRT_INVALID_PARM;

    sys_mutex_unlock((sys_mutex_t *)mutexHandle);

    return OPRT_OK;
}

/***********************************************************
*  Function: ReleaseMutexManage 释放互斥锁管理结构资源
*  Input: mutexHandle->互斥量句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_mutex_release(const MUTEX_HANDLE mutexHandle)
{
    sys_mutex_free((sys_mutex_t *)mutexHandle);
    tuya_hal_internal_free(mutexHandle);
 
    return OPRT_OK;
}


