#include "stdio.h"
#include "cmsis_os.h"
#include "tuya_hal_mutex.h"
#include "tuya_hal_storge.h"
#include "tuya_hal_fs.h"
#include "lwip/sys.h"
#include "rt_fs.h"
#include "tycam_rts_gpio.h"
#include "tycam_gpio.h"


static MUTEX_HANDLE s_mutex;

int test_arg[2] = {0,1};
void test_proc(void *arg)
{
    int index = *(int *)arg;

    int cnt = 10;

    printf("proc %d want a lock!\n", index);
    tuya_hal_mutex_lock(s_mutex);
    while(cnt > 0)
    {
        printf("[%d]print from:%d\n",cnt,index);
        cnt--;
        sys_msleep(100);
    }

    tuya_hal_mutex_unlock(s_mutex);

    printf("proc %d release a lock!\n", index);

    exit(0);
    
}



void begin_test()
{
	sys_thread_t ret = NULL;
    int i = 0;
    char name[16];


    tuya_hal_mutex_create_init(&s_mutex);
    printf("begin test!\n");
    for(i = 0; i <= 1; i++)
    {
        snprintf(name, 16, "test_proc_%d", i);
        ret = sys_thread_new(name, test_proc, &test_arg[i], 1024*1024, 3);
        
        if (ret == NULL) {
            printf("Create thread %s fail\n",name);
            return -1;
        }
        else
        {
            printf("Create thread %s ok\n",name);
        }        
    }

    sys_msleep(100);

	return 0;

}


void ty_test_flash()
{

    char *data = "test flash read and write!";
    char read_buf[148] = {0};

    //tuya_hal_flash_write(0x3f0000, data, strlen(data));

    
    tuya_hal_flash_read(0x3f0000, read_buf, 148);

    printf("read:%s\n",read_buf);

}

void ty_test_snprintf()
{
    char buf[16] = {0};
    snprintf(buf, 16, "%s%d","test",1);
    printf("@1buf:%s\n",buf);

    char tmp[32] = "abcdefgabcdefgabcdefgabcdefg";

    snprintf(buf, 16, "%s", tmp);

    printf("@2buf:%s\n", buf);
    
    snprintf(buf, 16, "%saa%d", tmp,2);

    printf("@3buf:%s\n", buf);
    
    char tt[16] ={0};

    int i = strlen(tt);
    printf("strlen of tt:%d\n", i);

    snprintf(buf, 16, "%sdd%d", tt, 3);
    printf("@4buf:%s\n", buf);

}

void ty_test_io()
{
    char path[128] = {0};

    char *buffer=  NULL;
    snprintf(path, 128, "/test/000.media");

    buffer = tuya_hal_internal_malloc(1024*1024);
    if(!buffer)
    {
        printf("malloc test buf error!\n");
        return;
    }
    int i = 0;
    for(i = 0; i < (1024*1024-1); i++)
    {
        buffer[i] = i;
    }
    buffer[1024*1024-1] = '\0';
    
    TUYA_FILE fp = tuya_hal_fopen(path,"a+");
    if(NULL == fp)
    {
        printf("fail to open %s\n",path);  //发生异常，缓存中的这部分数据丢失
    }
    else
    {
        
        int ret = tuya_hal_fwrite(buffer, 1024*1024, fp);
        tuya_hal_fsync(fp);
        if(ret <= 0)
        {
            printf("fwrite error! ret = %d\n", ret);
        }           
 
        tuya_hal_fclose(fp);
    }

    return;

}

void ty_test_speaker()
{
    char *filename = "one_8k.wav";
    tycam_stream_init();
    tycam_gpio_init();

    tycam_speaker_play_file(filename, 1);
}

void ty_test_sd(int mode)
{
    int cnt = 100;
    int total;
    int used;
    int free;
    
    while(cnt--)
    {
        if(mode == 1)
        {
            printf("get status :%d\n",tuya_ipc_sd_get_status());
        }
        else if(mode == 2)
        {
            tuya_ipc_sd_get_capacity(&total, &used, &free);
        }
      
        tuya_hal_system_sleep(1000);
    }
}

void ty_test_dir(char *path)
{
    uint32_t mode = 0;
    int ret = tuya_hal_fs_mode(path, &mode);
    if(ret != 0)
    {
        return;
    }

    printf("mode :%d\n",mode);
    return;
}

void ty_test_rename(char *path_old,char *path_new)
{
    int ret = rt_fs_rename(path_old, path_new);
    printf("%s!\n", ret ? "fail" : "success");
    return ret;

}

#define MAX_PATH 256
void ty_test_mv(char *in_src,char *in_dst)
{
    int     ret = RT_OK;
    char    src_path[MAX_PATH], dst_path[MAX_PATH];

    rt_fs_path_from_user(in_src, src_path);
    rt_fs_path_from_user(in_dst, dst_path);

    printf("src_path: %s\npath_dst: %s\n", src_path, dst_path);
    ret = rt_fs_rename(src_path, dst_path);
    rt_printf("%s!\n", ret ? "fail" : "success");
    return ret;

}

void ty_test_gpio()
{

    tuya_gpio_set_en(TYGPIO_DEV_RST,0);


    tuya_hal_system_sleep(250);


    int cnts = 30;
    unsigned char   en = 255;
    unsigned char  data = 255;

    
    while(cnts-- != 0)
    {
        // data: 0-press, 1-up
        tuya_gpio_get(TYGPIO_DEV_RST, &en, &data);

        printf("[%d] en:%d , data:%d\n",TYGPIO_DEV_RST,en,data);
        tuya_hal_system_sleep(1000);
    }
}
