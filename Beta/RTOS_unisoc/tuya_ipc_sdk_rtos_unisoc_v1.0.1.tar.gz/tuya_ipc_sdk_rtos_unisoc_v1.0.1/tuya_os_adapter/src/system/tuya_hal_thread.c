
//#include <cmsis_os.h>
#include "tuya_hal_thread.h"
#include "../errors_compat.h"

#include "lwip/sys.h"


int tuya_hal_thread_create(THREAD_HANDLE* thread,
                            const char* name,
                            uint32_t stack_size,
                            uint32_t priority,
                            THREAD_FUNC_T func,
                            void* const arg)
{
    if (NULL == thread) {
        return OPRT_INVALID_PARM;
    }

	sys_thread_t ret = NULL;

    if(priority > 0)
    {
        //--priority;
    }
    
    //if(stack_size < 8*1024)
    {
        //stack_size = 8*1024;
    }
    
	ret = sys_thread_new(name, func, arg, stack_size, priority);

	if (ret != 0) {
		printf("Create thread %s failed\n",name);
		return -1;
	}

    *thread = ret;
	return 0;
}

int tuya_hal_thread_release(THREAD_HANDLE thread)
{
    if (NULL == thread) {
        return OPRT_INVALID_PARM;
    }

    // delete thread process 
    //rda_thread_delete(thread);

    return OPRT_OK;
}

int tuya_hal_thread_is_self(THREAD_HANDLE thread, bool* is_self)
{
#if 0
    if (NULL == thread || NULL == is_self) {
        return OPRT_INVALID_PARM;
    }

    THREAD_HANDLE self_handle = rda_thread_get_id();
    if (NULL == self_handle) {
        return OPRT_COM_ERROR;
    }

    *is_self = (thread == self_handle);
#endif
    return OPRT_OK;
}

int tuya_hal_thread_set_self_name(const char* name)
{
    return OPRT_OK;
}

