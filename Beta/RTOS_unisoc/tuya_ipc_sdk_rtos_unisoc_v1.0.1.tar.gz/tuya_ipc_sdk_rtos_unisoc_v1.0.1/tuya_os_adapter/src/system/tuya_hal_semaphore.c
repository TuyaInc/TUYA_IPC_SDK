/***********************************************************
*  File: uni_semaphore.c
*  Author: nzy
*  Date: 120427
***********************************************************/
#define _UNI_SEMAPHORE_GLOBAL
//#include "rda_sys_wrapper.h"
//#include "cmsis_os.h"
#include "tuya_hal_semaphore.h"
#include "tuya_hal_system_internal.h"
#include "../errors_compat.h"
//#include "FreeRTOS.h"
//#include "semphr.h"

/***********************************************************
*************************micro define***********************
***********************************************************/

#if 0
#define LOGD PR_DEBUG
#define LOGT PR_TRACE
#define LOGN PR_NOTICE
#define LOGE PR_ERR
#else
#define LOGD(...) printf("[SEM DEBUG]" __VA_ARGS__)
#define LOGT(...) printf("[SEM TRACE]" __VA_ARGS__)
#define LOGN(...) printf("[SEM NOTICE]" __VA_ARGS__)
#define LOGE(...) printf("[SEM ERROR]" __VA_ARGS__)
#endif



typedef struct
{
    void* sem;
}SEM_MANAGE,*P_SEM_MANAGE;

#if 0
/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/
/***********************************************************
*  Function: CreateSemaphore 创建一个信号量
*  Input: reqSize->申请的内存大小
*  Output: none
*  Return: NULL失败，非NULL成功
*  Date: 120427
***********************************************************/
static SEM_HANDLE CreateSemaphore(void)
{
    P_SEM_MANAGE pSemManage;
    
    pSemManage = (P_SEM_MANAGE)tuya_hal_internal_malloc(sizeof(SEM_MANAGE));
	memset(pSemManage, 0, sizeof(SEM_MANAGE));
    return (SEM_HANDLE)pSemManage;
}

/***********************************************************
*  Function: InitSemaphore
*  Input: semHandle->信号量操作句柄
*         semCnt
*         sem_max->no use for linux os
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
static int InitSemaphore(const SEM_HANDLE semHandle, const uint32_t semCnt,\
                                 const uint32_t sem_max)
{
    if(!semHandle)
        return OPRT_INVALID_PARM;
        
    P_SEM_MANAGE pSemManage;
    pSemManage = (P_SEM_MANAGE)semHandle;

    pSemManage->sem = xSemaphoreCreateCounting(sem_max,semCnt);
    if(NULL == pSemManage->sem) {
        return OPRT_INIT_SEM_FAILED;
    }
    return OPRT_OK;
}

int tuya_hal_semaphore_create_init(SEM_HANDLE *pHandle, const uint32_t semCnt, \
                          const uint32_t sem_max)
{
    if(NULL == pHandle)
    {
        LOGE("invalid param\n");
        return OPRT_INVALID_PARM;
    }

    *pHandle = CreateSemaphore();
    if(*pHandle == NULL)
    {
        LOGE("malloc fails\n");
        return OPRT_MALLOC_FAILED;
    }

    int ret = InitSemaphore(*pHandle, semCnt, sem_max);

    if(ret != OPRT_OK)
    {
        tuya_hal_internal_free(*pHandle);
        *pHandle = NULL;
        LOGE("semaphore init fails %d %d\n", semCnt, sem_max);
        return ret;
    }

    return OPRT_OK;
}

/***********************************************************
*  Function: WaitSemaphore
*  Input: semHandle->信号量操作句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_semaphore_wait(const SEM_HANDLE semHandle)
{
#if 1
    if(!semHandle)
        return OPRT_INVALID_PARM;

    P_SEM_MANAGE pSemManage;
    pSemManage = (P_SEM_MANAGE)semHandle;

    int ret = xSemaphoreTake(pSemManage->sem, ( TickType_t ) 10 );

    if(pdTRUE == ret) {
        return OPRT_WAIT_SEM_FAILED;
    }
#endif
    return OPRT_OK;
}

/***********************************************************
*  Function: PostSemaphore
*  Input: semHandle->信号量操作句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_semaphore_post(const SEM_HANDLE semHandle)
{
#if 1
    if(!semHandle)
        return OPRT_INVALID_PARM;

    P_SEM_MANAGE pSemManage;
    pSemManage = (P_SEM_MANAGE)semHandle;

    int ret = xSemaphoreGive(pSemManage->sem);


    if (pdTRUE != ret) {
        return OPRT_POST_SEM_FAILED;
    }
#endif
    return OPRT_OK;
}

/***********************************************************
*  Function: ReleaseSemaphore
*  Input: semHandle->信号量操作句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_semaphore_release(const SEM_HANDLE semHandle)
{
#if 1
    if(!semHandle)
        return OPRT_INVALID_PARM;

    P_SEM_MANAGE pSemManage;
    pSemManage = (P_SEM_MANAGE)semHandle;

    vSemaphoreDelete(pSemManage->sem);
    tuya_hal_internal_free(semHandle); // 释放信号量管理结构
#endif
    return OPRT_OK;
}
#else
#include "lwip/sys.h"

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/
/***********************************************************
*  Function: CreateSemaphore 创建一个信号量
*  Input: reqSize->申请的内存大小
*  Output: none
*  Return: NULL失败，非NULL成功
*  Date: 120427
***********************************************************/
static SEM_HANDLE CreateSemaphore(void)
{
    P_SEM_MANAGE pSemManage;
    
    pSemManage = (P_SEM_MANAGE)tuya_hal_internal_malloc(sizeof(SEM_MANAGE));
	memset(pSemManage, 0, sizeof(SEM_MANAGE));
    return (SEM_HANDLE)pSemManage;
}

/***********************************************************
*  Function: InitSemaphore
*  Input: semHandle->信号量操作句柄
*         semCnt
*         sem_max->no use for linux os
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
static int InitSemaphore(const SEM_HANDLE semHandle, const uint32_t semCnt,\
                                 const uint32_t sem_max)
{
    if(!semHandle)
        return OPRT_INVALID_PARM;
        
    P_SEM_MANAGE pSemManage;
    pSemManage = (P_SEM_MANAGE)semHandle;

    pSemManage->sem = xSemaphoreCreateCounting(sem_max,semCnt);
    if(NULL == pSemManage->sem) {
        return OPRT_INIT_SEM_FAILED;
    }
    return OPRT_OK;
}

int tuya_hal_semaphore_create_init(SEM_HANDLE *pHandle, const uint32_t semCnt, \
                          const uint32_t sem_max)
{
     if(!pHandle)
         return OPRT_INVALID_PARM;
     
     sys_sem_t *sys_sem = NULL;
     sys_sem = (sys_sem_t *)tuya_hal_internal_malloc(sizeof(sys_sem_t));
     if(!(sys_sem))
         return OPRT_MALLOC_FAILED;
         
     sys_sem_new(sys_sem,semCnt);
     
     //if (sys_sem->id == NULL)
     //    return OPRT_INIT_SEM_FAILED;
     
     *pHandle = (SEM_HANDLE *)sys_sem;
     
     return OPRT_OK;

}

/***********************************************************
*  Function: WaitSemaphore
*  Input: semHandle->信号量操作句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_semaphore_wait(const SEM_HANDLE semHandle)
{
#if 1
    if(!semHandle)
        return OPRT_INVALID_PARM;

    sys_arch_sem_wait((sys_sem_t *)semHandle, 0);
#endif
    return OPRT_OK;
}

/***********************************************************
*  Function: PostSemaphore
*  Input: semHandle->信号量操作句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_semaphore_post(const SEM_HANDLE semHandle)
{
#if 1
    if(!semHandle)
        return OPRT_INVALID_PARM;

    sys_sem_signal((sys_sem_t *)semHandle);
#endif
    return OPRT_OK;
}

/***********************************************************
*  Function: ReleaseSemaphore
*  Input: semHandle->信号量操作句柄
*  Output: none
*  Return: OPERATE_RET
*  Date: 120427
***********************************************************/
int tuya_hal_semaphore_release(const SEM_HANDLE semHandle)
{
#if 1
    if(!semHandle)
        return OPRT_INVALID_PARM;

    sys_sem_free((sys_sem_t *)semHandle);
    tuya_hal_internal_free(semHandle); // 释放信号量管理结构
#endif
    return OPRT_OK;
}

#endif

