#include "tuya_hal_fs.h"
//#include "rt_fs.h"
//#include "ff.h"

typedef struct {
    //DIR tuya_dir;
    //FILINFO tuya_filenfo;
} TUYADIR_S;

typedef struct _tuya_Opt_FIL_
{
    //FIL opt_file;           //操作文件句柄;
    //int32_t index_offset;  //文件offset位置;
}tuya_Opt_FIL;

int tuya_hal_fs_mkdir(const char* path)
{return 0;}

int tuya_hal_fs_remove(const char* path)
{return 0;}

int tuya_hal_fs_mode(const char* path, uint32_t* mode)
{return 0;}

int tuya_hal_fs_is_exist(const char* path, bool* is_exist)
{
   //*is_exist = rt_fs_is_exist(path);
   return 0;
}

int tuya_hal_dir_open(const char* path, TUYA_DIR* dir)
{return 0;}

int tuya_hal_dir_close(TUYA_DIR dir)
{return 0;}

int tuya_hal_dir_read(TUYA_DIR dir, TUYA_FILEINFO* info)
{return 0;}

int tuya_hal_dir_name(TUYA_FILEINFO info, const char** name)
{return 0;}

int tuya_hal_dir_is_directory(TUYA_FILEINFO info, bool* is_dir)
{return 0;}

int tuya_hal_dir_is_regular(TUYA_FILEINFO info, bool* is_regular)
{return 0;}

int tuya_hal_fs_rename(char *path_old,char *path_new)
{return 0;}

TUYA_FILE tuya_hal_fopen(const char* path, const char* mode)
{return 0;}

int tuya_hal_fclose(TUYA_FILE file)
{return 0;}

int tuya_hal_fread(void* buf, int bytes, TUYA_FILE file)
{return 0;}

int tuya_hal_fwrite(void* buf, int bytes, TUYA_FILE file)
{return 0;}

int tuya_hal_fsync(TUYA_FILE file)
{return 0;}

char* tuya_hal_fgets(char* buf, int len, TUYA_FILE file)
{return 0;}

int tuya_hal_feof(TUYA_FILE file)
{return 0;}

int tuya_hal_fseek(TUYA_FILE file, int32_t offs, int whence)
{return 0;}

int64_t tuya_hal_ftell(TUYA_FILE file)
{return 0;}


