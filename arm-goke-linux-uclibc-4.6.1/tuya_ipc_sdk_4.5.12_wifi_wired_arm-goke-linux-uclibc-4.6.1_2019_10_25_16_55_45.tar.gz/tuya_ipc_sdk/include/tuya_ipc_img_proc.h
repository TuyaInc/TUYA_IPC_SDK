/*********************************************************************************
* Copyright(C),2019, TUYA www.tuya.com

* FileName:		tuya_ipc_img_proc.h
* Note			tuya_ipc_img_proc api
* Version		V1.0.0
* Data			2019.04
**********************************************************************************/

#ifndef _TUYA_IPC_IMG_PROC_H_
#define _TUYA_IPC_IMG_PROC_H_

#include "tuya_cloud_types.h" 
#include "tuya_cloud_error_code.h"

#define IMP_128_SHIFT8          (32768)

#ifdef __cplusplus
extern "C" {
#endif

	/*********************************************************************************
	* Image resize enum
	* lINEAR		Faster but low quality
	* CUBIC			Slower but high quality
	**********************************************************************************/
	typedef enum
	{
		LINEAR,
		CUBIC,

	}IMG_RESIZE_TYPE;

	/*********************************************************************************
	* Image resize struct, please scale the width and height equally 
	* srcWidth		Input width
	* srcHeight		Input height
	* dstWidth		Output width
	* dstHeight		Output height
	* type			Scale type
	**********************************************************************************/
	typedef struct _TUYA_IMG_RESIZE_PARA
	{
		INT_T srcWidth;
		INT_T srcHeight;
		INT_T dstWidth;
		INT_T dstHeight;
		IMG_RESIZE_TYPE type;

	}TUYA_IMG_RESIZE_PARA;

	/*********************************************************************************
	* YUV420 image scale interface
    * in_data  		input YUV420
	* paras			scale struct	
	* out_data		output YUV420
	**********************************************************************************/
	OPERATE_RET Tuya_Ipc_Img_Resize(UCHAR_T *in_data, TUYA_IMG_RESIZE_PARA paras, UCHAR_T *out_data);






#ifdef __cplusplus
}
#endif

#endif // !_TUYA_IPC_IMG_PROC_H_
