/***********************************************************
*  File: uni_storge.h 
*  Author: nzy
*  Date: 20170920
***********************************************************/
#ifndef _TUYA_IPC_STORAGE_H
#define _TUYA_IPC_STORAGE_H

#include "tuya_cloud_types.h"

#ifdef __cplusplus
	extern "C" {
#endif

#define __UNI_STORGE_MODULE_EXT extern

/***********************************************************
*************************micro define***********************
***********************************************************/
typedef struct {
    UINT start_addr; // user physical flash start address 
    UINT flash_sz; // user flash size
    UINT block_sz; // flash block/sector size

    // For data backup and power down protection data recovery
    UINT swap_start_addr; // swap flash start address
    UINT swap_flash_sz; // swap flash size    
}UNI_STORGE_DESC_S;



/**
 * \typedef  typedef OPERATE_RET (*GW_FLASH_READ_CB)(IN CONST UINT addr, OUT BYTE *dst, IN CONST UINT size)
  * \brief 针对无文件系统的情况下，对flash的读操作
 * \param[in] addr: flash start address
 * \param[out] dst: 读取数据的内存地址
 * \param[in] size: 读取数据的大小
 */
typedef OPERATE_RET (*GW_FLASH_READ_CB)(IN CONST UINT addr, OUT BYTE *dst, IN CONST UINT size);

/**
 * \typedef  typedef OPERATE_RET (*GW_FLASH_WRITE_CB)(IN CONST UINT addr, IN CONST BYTE *src, IN CONST UINT size)
  * \brief 针对无文件系统的情况下，对flash的写操作
 * \param[in] addr: flash start address
 * \param[in] src: 写数据的内存地址
 * \param[in] size: 写数据的大小
 */
typedef OPERATE_RET (*GW_FLASH_WRITE_CB)(IN CONST UINT addr, IN CONST BYTE *src, IN CONST UINT size);

/**
 * \typedef  typedef OPERATE_RET (*GW_FLASH_ERASE_CB)(IN CONST UINT addr, IN CONST UINT size)
  * \brief 针对无文件系统的情况下，对flash的擦操作
 * \param[in] addr: flash start address
 * \param[in] size: 擦大小
 */
typedef OPERATE_RET (*GW_FLASH_ERASE_CB)(IN CONST UINT addr, IN CONST UINT size);

/**
 * \typedef  typedef OPERATE_RET (*GW_GET_STORAGE_DESC_CB)(UNI_STORGE_DESC_S *storge)
  * \brief 针对无文件系统的情况下，读取flash的相关信息
 * \param[in] addr: flash start address
 * \param[in] size: 擦大小
 */
typedef OPERATE_RET (*GW_GET_STORAGE_DESC_CB)(UNI_STORGE_DESC_S *storge);


__UNI_STORGE_MODULE_EXT GW_FLASH_READ_CB gw_flash_read_cb;

__UNI_STORGE_MODULE_EXT GW_FLASH_WRITE_CB gw_flash_write_cb;

__UNI_STORGE_MODULE_EXT GW_FLASH_ERASE_CB gw_flash_erase_cb;

__UNI_STORGE_MODULE_EXT GW_GET_STORAGE_DESC_CB gw_flash_storage_desc_cb;


/**
 * \fn OPERATE_RET tuya_ipc_set_flash_read_cb(IN CONST GW_FLASH_READ_CB flash_read_cb)
 * \brief 设置读取flash的回调函数
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_set_flash_read_cb(IN CONST GW_FLASH_READ_CB flash_read_cb);

/**
 * \fn OPERATE_RET tuya_ipc_set_flash_write_cb(IN CONST GW_FLASH_WRITE_CB write_read_cb)
 * \brief 设置写flash的回调函数
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_set_flash_write_cb(IN CONST GW_FLASH_WRITE_CB write_read_cb);

/**
 * \fn OPERATE_RET tuya_ipc_set_flash_erase_cb(IN CONST GW_FLASH_ERASE_CB erase_cb)
 * \brief 设置擦flash的回调函数
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_set_flash_erase_cb(IN CONST GW_FLASH_ERASE_CB erase_cb);

/**
 * \fn OPERATE_RET tuya_ipc_set_storage_desc_cb(IN CONST GW_GET_STORAGE_DESC_CB storage_desc_cb)
  * \brief 获取flash的一些信息，如分区，其实地址等
 * \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_set_storage_desc_cb(IN CONST GW_GET_STORAGE_DESC_CB storage_desc_cb);


#ifdef __cplusplus
}
#endif
#endif

