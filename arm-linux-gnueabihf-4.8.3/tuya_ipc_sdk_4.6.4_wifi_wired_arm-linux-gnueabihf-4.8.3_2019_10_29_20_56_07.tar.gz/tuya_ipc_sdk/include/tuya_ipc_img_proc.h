/*********************************************************************************
* Copyright(C),2019, TUYA www.tuya.com

* FileName:		tuya_ipc_img_proc.h
* Note			tuya_ipc_img_proc api
* Version		V1.0.0
* Data			2019.04
**********************************************************************************/

#ifndef _TUYA_IPC_IMG_PROC_H_
#define _TUYA_IPC_IMG_PROC_H_

#include "tuya_cloud_types.h" 
#include "tuya_cloud_error_code.h"

#ifdef __cplusplus
extern "C" {
#endif

	/*********************************************************************************
	* Image type
	* Y				
	* YUV	
	* BGR
	**********************************************************************************/
	typedef enum
	{
		Y,
		YUV,
	}IMG_TYPE;

	/*********************************************************************************
	* Image resize enum
	* lINEAR		Faster but low quality
	* CUBIC			Slower but high quality
	**********************************************************************************/
	typedef enum
	{
		LINEAR,
		CUBIC,

	}IMG_RESIZE_TYPE;

	/*********************************************************************************
	* Image resize struct, please scale the width and height equally 
	* srcWidth		Input width
	* srcHeight		Input height
	* dstWidth		Output width
	* dstHeight		Output height
	* type			Scale type
	**********************************************************************************/
	typedef struct _TUYA_IMG_RESIZE_PARA
	{
		INT_T srcWidth;
		INT_T srcHeight;
		INT_T dstWidth;
		INT_T dstHeight;
		IMG_TYPE img_type;
		IMG_RESIZE_TYPE resize_type;

	}TUYA_IMG_RESIZE_PARA;

	/*********************************************************************************
	* YUV420 image scale interface
    * in_data  		input YUV420
	* paras			scale struct	
	* out_data		output YUV420
	**********************************************************************************/
	OPERATE_RET Tuya_Ipc_Img_Resize(UCHAR_T *in_data, TUYA_IMG_RESIZE_PARA paras, UCHAR_T *out_data);



	/*********************************************************************************
	* yuv4202b8g8r8
	**********************************************************************************/
	OPERATE_RET IMP_DataConvert_yuv4202b8g8r8(UCHAR_T *yImg, UCHAR_T *uImg, UCHAR_T *vImg, INT_T width,
		INT_T height, UCHAR_T *dstB, UCHAR_T *dstG, UCHAR_T *dstR);


	/*********************************************************************************
	* rect of TUYA  AI
	**********************************************************************************/
	typedef struct _TUYA_RECT_AI
	{
		INT_T left;
		INT_T top;
		INT_T right;
		INT_T bottom;
	}TUYA_AI_RECT;

	/*********************************************************************************
	* spec of TUYA  AI
	**********************************************************************************/
	typedef struct _TUYA_AI_SPEC
	{
		INT_T num;
		INT_T* pclass;
		TUYA_AI_RECT* rect;
	}TUYA_AI_SPEC;

	/*********************************************************************************
	* draw rect to Yuv
	**********************************************************************************/
	OPERATE_RET IMP_DrawRect_YUV(UCHAR_T *yImg, INT_T width, INT_T height, TUYA_AI_SPEC ai_spec);
	
	/*********************************************************************************
	* get Yuv of the first rect
	**********************************************************************************/
	OPERATE_RET IMP_Get_Rect_YUV(UCHAR_T *srcImg, INT_T width, INT_T height, TUYA_AI_SPEC ai_spec, UCHAR_T *dstImg);

#ifdef __cplusplus
}
#endif

#endif // !_TUYA_IPC_IMG_PROC_H_
